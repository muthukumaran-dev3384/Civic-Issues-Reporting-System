<?php
session_start();
include 'db.php';

$emailPrefill = $_GET['email'] ?? '';
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = strtolower(trim($_POST['email'])); // normalize email

    // Validate email format
    if ($email === '') {
        $error = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {

        // Check duplicate email
        $check = $conn->prepare("SELECT id FROM users WHERE LOWER(TRIM(email)) = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = "Email already registered.";
        } else {
            // Insert user
            $stmt = $conn->prepare("INSERT INTO users (email) VALUES (?)");
            $stmt->bind_param("s", $email);

            if ($stmt->execute()) {
                // Account created successfully → redirect to login
                $_SESSION['signup_success'] = "Account created successfully! Please login.";
                header("Location: login.php?email=" . urlencode($email));
                exit;
            } else {
                $error = "Signup failed. Please try again.";
            }
            $stmt->close();
        }
        $check->close();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Email Signup</title>
<style>
:root{
    --primary:#2563eb;
    --success:#16a34a;
    --error:#dc2626;
    --bg:#eef2f8;
}
*{box-sizing:border-box;}
body{
    margin:0;
    height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    font-family:'Inter', Arial, sans-serif;
    background:linear-gradient(135deg,#e0e7ff,#f8fafc);
}
.box{
    width:380px;
    background:#ffffff;
    padding:34px 30px;
    border-radius:18px;
    text-align:center;
    box-shadow:0 25px 50px rgba(0,0,0,.15);
}
.box h2{margin:0 0 20px;font-size:24px;color:#0f172a;}
input{
    width:100%;
    height:48px;
    padding:0 14px;
    margin-top:12px;
    border-radius:12px;
    border:1.5px solid #cbd5e1;
    font-size:15px;
    font-weight:500;
    outline:none;
    transition:.25s;
}
input:focus{
    border-color:var(--primary);
    box-shadow:0 0 0 3px rgba(37,99,235,.15);
}
button{
    width:100%;
    height:48px;
    margin-top:18px;
    border:none;
    border-radius:12px;
    background:var(--success);
    color:#fff;
    font-size:16px;
    font-weight:700;
    cursor:pointer;
    transition:.25s;
}
button:hover{
    transform:translateY(-2px);
    box-shadow:0 12px 25px rgba(22,163,74,.35);
}
.error,
.success{
    padding:12px;
    border-radius:10px;
    font-size:14px;
    font-weight:600;
    margin-bottom:14px;
}
.error{background:#fee2e2;color:var(--error);}
.success{background:#dcfce7;color:#166534;}
@media(max-width:420px){
    .box{width:92%;}
}
</style>
</head>

<body>

<div class="box">
    <h2>Create Account</h2>

    <?php 
    if ($error !== '') echo "<div class='error'>" . htmlspecialchars($error) . "</div>";
    ?>

    <form method="POST">
        <input 
            type="email" 
            name="email" 
            placeholder="Enter your email address"
            required 
            value="<?= htmlspecialchars($emailPrefill); ?>"
        >
        <button type="submit">Create Account</button>
    </form>
</div>

</body>
</html>