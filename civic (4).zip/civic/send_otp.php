<?php
session_start();
if (!isset($_SESSION['email']) || !isset($_SESSION['otp'])) {
    die("Invalid session. Go back and login again.");
}

$email = $_SESSION['email'];
$otp   = $_SESSION['otp'];

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;

    // GMAIL HERE
    $mail->Username   = 'your email'; 
    //  16 DIGIT APP PASSWORD HERE
    $mail->Password   = 'password here';

    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    $mail->setFrom('your email', 'Civic Issue Portal');
    $mail->addAddress($email);

    $mail->Subject = "Your Login OTP";
    $mail->Body    = "Your OTP is: $otp";

    $mail->send();

    header("Location: verify_otp.php");
    exit;

} catch (Exception $e) {
    echo "Email sending failed: " . $mail->ErrorInfo;
}
?>