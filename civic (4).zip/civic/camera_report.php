<?php
session_start();

/* ---------- CATEGORY HANDLING (FIX) ---------- */
$category = $_GET['cat'] ?? '';

$allowedCategories = [
    'road',
    'electricity',
    'water',
    'garbage',
    'streetlight',
    'drainage'
];

if (!in_array($category, $allowedCategories)) {
    die("Invalid Complaint Category");
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Smart Complaint Capture</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

<style>
*{box-sizing:border-box}
body{
    margin:0;
    font-family:Poppins,sans-serif;
    background:linear-gradient(135deg,#e0f2fe,#eef2ff);
}
.container{
    max-width:520px;
    margin:40px auto;
    padding:15px;
}
.card{
    background:#fff;
    padding:26px;
    border-radius:22px;
    box-shadow:0 25px 60px rgba(0,0,0,.18);
}
h2{
    text-align:center;
    margin-bottom:8px;
}
.sub{
    text-align:center;
    color:#64748b;
    margin-bottom:14px;
}
.status{
    text-align:center;
    padding:10px;
    border-radius:12px;
    font-weight:600;
    margin-bottom:14px;
}
.wait{background:#f59e0b;color:#fff}
.ok{background:#16a34a;color:#fff}
.err{background:#dc2626;color:#fff}

video,canvas{
    width:100%;
    border-radius:16px;
    margin-top:10px;
}
.btn{
    width:100%;
    padding:14px;
    background:#2563eb;
    color:#fff;
    border:none;
    border-radius:14px;
    font-size:16px;
    font-weight:600;
    margin-top:14px;
    cursor:pointer;
}
.btn:disabled{background:#93c5fd}

label{
    display:block;
    margin-top:14px;
    font-weight:500;
}
input,textarea,select{
    width:100%;
    padding:12px;
    margin-top:6px;
    border-radius:12px;
    border:1px solid #cbd5e1;
    font-family:Poppins;
}
.footer-note{
    text-align:center;
    font-size:13px;
    color:#64748b;
    margin-top:12px;
}
.category-badge{
    text-align:center;
    background:#2563eb;
    color:#fff;
    padding:6px 14px;
    border-radius:999px;
    font-size:13px;
    display:inline-block;
    margin:0 auto 12px;
}
</style>
</head>

<body>
<div class="container">
<div class="card">

<h2>📸 Smart Complaint</h2>
<div class="sub">Capture issue with live location</div>

<div style="text-align:center">
    <span class="category-badge">
        Category: <?php echo strtoupper($category); ?>
    </span>
</div>

<div id="gpsStatus" class="status wait">📍 Getting accurate location…</div>

<video id="video" autoplay playsinline></video>
<canvas id="canvas" style="display:none"></canvas>

<button id="captureBtn" class="btn" disabled>📸 Capture Photo</button>

<form method="POST" action="upload.php">

<!-- 🔥 IMPORTANT FIX -->
<input type="hidden" name="category" value="<?php echo htmlspecialchars($category); ?>">

<input type="hidden" name="photo" id="photo">
<input type="hidden" name="latitude" id="lat">
<input type="hidden" name="longitude" id="lng">
<input type="hidden" name="city" id="city">
<input type="hidden" name="area" id="area">
<input type="hidden" name="road" id="road">
<input type="hidden" name="created_at" id="time">
<label>📞 Phone Number</label>
<input
    type="tel"
    name="phone"
    required
    pattern="[0-9]{10}"
    maxlength="10"
    inputmode="numeric"
    placeholder="Enter 10-digit mobile number"
    title="Please enter exactly 10 digits"
/>

<label>📝 Description (Optional)</label>
<textarea
    name="description"
    rows="3"
    placeholder="Describe the issue (optional)"
></textarea>


<label>⚡ Priority</label>
<select name="priority">
    <option>Low</option>
    <option selected>Medium</option>
    <option>High</option>
</select>

<button class="btn" id="submitBtn" disabled>🚀 Submit Complaint</button>
</form>

<div class="footer-note">
⚠ Location depends on GPS & network accuracy
</div>

</div>
</div>

<script>
const video = document.getElementById("video");
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

const gpsStatus = document.getElementById("gpsStatus");
const captureBtn = document.getElementById("captureBtn");
const submitBtn = document.getElementById("submitBtn");

const lat = document.getElementById("lat");
const lng = document.getElementById("lng");
const city = document.getElementById("city");
const area = document.getElementById("area");
const road = document.getElementById("road");
const photo = document.getElementById("photo");
const time = document.getElementById("time");

/* ================= CAMERA ================= */
navigator.mediaDevices.getUserMedia({
    video:{ facingMode:{ ideal:"environment" } }
}).then(stream=>{
    video.srcObject = stream;
}).catch(()=>{
    alert("Camera permission required");
});

/* ================= LOCATION (ROBUST) ================= */
let bestPosition = null;
let bestAccuracy = Infinity;
let locationAccepted = false;

if (!navigator.geolocation) {
    gpsStatus.className="status err";
    gpsStatus.innerText="❌ Geolocation not supported";
} else {

    gpsStatus.innerText="📡 Getting location…";

    const watchId = navigator.geolocation.watchPosition(
        pos => {
            const acc = pos.coords.accuracy;

            // keep best position
            if (acc < bestAccuracy) {
                bestAccuracy = acc;
                bestPosition = pos;
            }

            gpsStatus.innerText = `📡 Accuracy: ${Math.round(acc)}m`;

            // accept if good enough
            if (acc <= 80 && !locationAccepted) {
                acceptLocation(bestPosition);
                navigator.geolocation.clearWatch(watchId);
            }
        },
        err => {
            gpsStatus.className="status err";
            gpsStatus.innerText="❌ Enable GPS / Wi-Fi and reload";
        },
        {
            enableHighAccuracy: true,
            timeout: 50000,
            maximumAge: 0
        }
    );

    // ⏱️ FORCE ACCEPT AFTER 15 SECONDS
    setTimeout(() => {
        if (!locationAccepted && bestPosition) {
            acceptLocation(bestPosition);
            navigator.geolocation.clearWatch(watchId);
        }
    }, 20000);
}

/* ================= ACCEPT LOCATION ================= */
function acceptLocation(pos) {
    locationAccepted = true;

    lat.value = pos.coords.latitude.toFixed(6);
    lng.value = pos.coords.longitude.toFixed(6);

    gpsStatus.className = "status ok";
    gpsStatus.innerText =
        `📍 Location fixed (~${Math.round(pos.coords.accuracy)}m)`;

    captureBtn.disabled = false;

    // Reverse geocode
    fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat.value}&lon=${lng.value}`)
    .then(r=>r.json())
    .then(d=>{
        const a = d.address || {};
        city.value = a.city || a.town || a.village || a.county || "";
        area.value = a.suburb || a.neighbourhood || a.village || "";
        road.value = a.road || "";
    });
}

/* ================= CAPTURE ================= */
captureBtn.onclick = () => {
    canvas.style.display="block";
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    ctx.drawImage(video,0,0);

    ctx.fillStyle="rgba(0,0,0,.65)";
    ctx.fillRect(0,canvas.height-160,canvas.width,160);

    ctx.fillStyle="#fff";
    ctx.font="15px Poppins";

    let y = canvas.height-130;
    ctx.fillText(`Lat: ${lat.value}`,10,y);
    ctx.fillText(`Lng: ${lng.value}`,10,y+=24);
    ctx.fillText(`City: ${city.value}`,10,y+=24);
    ctx.fillText(`Area: ${area.value}`,10,y+=24);
    ctx.fillText(`Road: ${road.value}`,10,y+=24);

    photo.value = canvas.toDataURL("image/jpeg",0.9);
    time.value = new Date().toISOString().slice(0,19).replace("T"," ");

    submitBtn.disabled = false;
};
</script>
</body>
</html>
