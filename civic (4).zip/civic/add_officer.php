<?php
session_start();
include 'db.php';

/* ---------- ADMIN AUTH ---------- */
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

/* ---------- DELETE OFFICER ---------- */
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM officers WHERE id=$id");
    header("Location: add_officer.php?msg=deleted");
    exit;
}

/* ---------- FETCH SINGLE FOR EDIT ---------- */
$editData = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $result = $conn->query("SELECT * FROM officers WHERE id=$id");
    $editData = $result->fetch_assoc();
}

/* ---------- ADD / UPDATE OFFICER ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name']);
    $dept = trim($_POST['department']);
    $username = trim($_POST['username']);

    if (!empty($_POST['edit_id'])) {
        $id = intval($_POST['edit_id']);
        $conn->query("UPDATE officers 
                      SET name='$name', department='$dept', username='$username' 
                      WHERE id=$id");

        // Redirect to remove edit mode
        header("Location: add_officer.php?msg=updated");
        exit;

    } else {
        $password = hash('sha256', $_POST['password']);
        $stmt = $conn->prepare(
            "INSERT INTO officers (name, department, username, password) VALUES (?,?,?,?)"
        );
        $stmt->bind_param("ssss", $name, $dept, $username, $password);
        $stmt->execute();

        header("Location: add_officer.php?msg=added");
        exit;
    }
}

/* ---------- FETCH OFFICERS ---------- */
$officers = $conn->query("SELECT id,name,department,username FROM officers ORDER BY id DESC");

$msg = $_GET['msg'] ?? "";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Officer Management</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;}

body{
    background:linear-gradient(120deg,#e3f2fd,#f5f7fb);
    padding:40px 20px;
}

.container{max-width:1200px;margin:auto;}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
}

h1{font-size:24px;color:#0f172a;}

.btn{
    padding:8px 14px;
    border-radius:6px;
    text-decoration:none;
    font-size:13px;
    font-weight:500;
    display:inline-flex;
    align-items:center;
    gap:5px;
    transition:.3s;
    cursor:pointer;
    border:none;
}

/* Button Styles */
.btn-back{background:#ef4444;color:#fff;}
.btn-back:hover{background:#dc2626;}

.btn-primary{background:#2563eb;color:#fff;}
.btn-primary:hover{background:#1d4ed8;}

.btn-edit{
    background:#f59e0b;
    color:#fff;
}
.btn-edit:hover{
    background:#d97706;
}

.btn-delete{
    background:#dc2626;
    color:#fff;
}
.btn-delete:hover{
    background:#b91c1c;
}

.card{
    background:#fff;
    padding:25px;
    border-radius:12px;
    box-shadow:0 8px 20px rgba(0,0,0,.08);
    margin-bottom:30px;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    margin-top:15px;
}

th,td{
    padding:12px;
    text-align:left;
    font-size:14px;
}


th{
    background:#0f172a;
    color:#fff;
    padding:14px;
    font-size:14px;
    text-align:left;
}

tr{
    border-bottom:1px solid #e2e8f0;
}

.actions{
    display:flex;
    gap:6px;
}

/* FORM */
.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:18px;
}

.form-group{
    display:flex;
    flex-direction:column;
}

.form-group label{
    margin-bottom:5px;
    font-size:14px;
    font-weight:500;
}

.form-group input{
    padding:10px;
    border:1px solid #cbd5e1;
    border-radius:6px;
    font-size:14px;
}

.full-width{
    grid-column:1/-1;
    text-align:center;
    margin-top:10px;
}

.success{
    background:#22c55e;
    color:#fff;
    padding:10px;
    border-radius:6px;
    margin-bottom:15px;
    font-size:14px;
}

@media(max-width:768px){
    .form-grid{grid-template-columns:1fr;}
}
</style>
</head>

<body>
<div class="container">

<div class="header">
    <h1><i class="fa-solid fa-users"></i> Officer Management</h1>
    <a href="admin_panel.php" class="btn btn-back">
        <i class="fa-solid fa-arrow-left"></i> Back
    </a>
</div>

<!-- SUCCESS MESSAGE -->
<?php if($msg=="added"){ ?>
<div class="success">Officer added successfully!</div>
<?php } ?>
<?php if($msg=="updated"){ ?>
<div class="success">Officer updated successfully!</div>
<?php } ?>
<?php if($msg=="deleted"){ ?>
<div class="success">Officer deleted successfully!</div>
<?php } ?>

<!-- OFFICER TABLE -->
<div class="card">
<h3>Existing Officers</h3>
<table>
<tr>
<th>ID</th>
<th>Name</th>
<th>Department</th>
<th>Username</th>
<th>Actions</th>
</tr>

<?php while($o = $officers->fetch_assoc()){ ?>
<tr>
<td><?= $o['id'] ?></td>
<td><?= htmlspecialchars($o['name']) ?></td>
<td><?= htmlspecialchars($o['department']) ?></td>
<td><?= htmlspecialchars($o['username']) ?></td>
<td>
<div class="actions">
    <a href="?edit=<?= $o['id'] ?>" class="btn btn-edit">
        <i class="fa-solid fa-pen"></i> Edit
    </a>
    <a href="?delete=<?= $o['id'] ?>" 
       onclick="return confirm('Delete this officer?')" 
       class="btn btn-delete">
        <i class="fa-solid fa-trash"></i> Delete
    </a>
</div>
</td>
</tr>
<?php } ?>
</table>
</div>

<!-- ADD / EDIT FORM -->
<div class="card">
<h3><?= $editData ? "Edit Officer" : "Add New Officer" ?></h3>

<form method="POST">
<input type="hidden" name="edit_id" value="<?= $editData['id'] ?? '' ?>">

<div class="form-grid">

<div class="form-group">
<label>Name</label>
<input type="text" name="name" required value="<?= $editData['name'] ?? '' ?>">
</div>

<div class="form-group">
<label>Department</label>
<input type="text" name="department" required value="<?= $editData['department'] ?? '' ?>">
</div>

<div class="form-group">
<label>Username</label>
<input type="text" name="username" required value="<?= $editData['username'] ?? '' ?>">
</div>

<?php if(!$editData){ ?>
<div class="form-group">
<label>Password</label>
<input type="password" name="password" required>
</div>
<?php } ?>

<div class="full-width">
<button class="btn btn-primary" type="submit">
<i class="fa-solid fa-save"></i>
<?= $editData ? "Update Officer" : "Save Officer" ?>
</button>
</div>

</div>
</form>
</div>

</div>
</body>
</html>