<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Our Services |  Civic</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
/* ---------- GLOBAL ---------- */
body{
    margin:0;
    font-family:'Segoe UI', Arial, sans-serif;
    background:
        linear-gradient(rgba(0,0,0,.55), rgba(0,0,0,.55));
    background-size:cover;
    background-position:center;
    color:#fff;
}

/* ---------- HEADER ---------- */
.header{
    background:rgba(13,71,161,.9);
    padding:16px 30px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}
.header h2{
    margin:0;
    font-size:22px;
}
.header a{
    color:#fff;
    text-decoration:none;
    margin-left:12px;
    padding:6px 14px;
    background:rgba(255,255,255,.15);
    border-radius:6px;
}
.header a:hover{
    background:#fff;
    color:#0d47a1;
}

/* ---------- HERO ---------- */
.hero{
    text-align:center;
    padding:60px 20px 30px;
}
.hero h1{
    font-size:36px;
    margin-bottom:10px;
}
.hero p{
    max-width:700px;
    margin:auto;
    font-size:16px;
    opacity:.9;
}

/* ---------- SERVICES ---------- */
.services{
    padding:40px 40px 60px;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(260px,1fr));
    gap:25px;
}

.service-card{
    background:rgba(255,255,255,.92);
    color:#333;
    border-radius:16px;
    padding:28px;
    text-align:center;
    box-shadow:0 10px 25px rgba(0,0,0,.25);
    transition:.3s;
}
.service-card:hover{
    transform:translateY(-8px);
}

.service-card i{
    font-size:42px;
    color:#0d47a1;
    margin-bottom:14px;
}

.service-card h3{
    margin:10px 0;
    font-size:20px;
}

.service-card p{
    font-size:14px;
    color:#555;
}

/* ---------- FOOTER ---------- */
.footer{
    background:#0d47a1;
    text-align:center;
    padding:14px;
    font-size:13px;
}

/* ---------- MOBILE ---------- */
@media(max-width:768px){
    .hero h1{font-size:28px}
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <h2><i class="fa fa-city"></i>  Civic</h2>
    <div>
        <a href="index.php"><i class="fa fa-home"></i> Home</a>
        <a href="user_dashboard.php"><i class="fa fa-chart-line"></i> Dashboard</a>
        <a href="feedback.php"><i class="fa fa-comment-dots"></i> Feedback</a>
    </div>
</div>

<!-- HERO -->
<div class="hero">
    <h1>Our Services</h1>
    <p>
        Smart Civic Complaint Management System provides fast, transparent and
        efficient public service complaint handling for citizens and government officers.
    </p>
</div>

<!-- SERVICES GRID -->
<div class="services">

    <div class="service-card">
        <i class="fa fa-road"></i>
        <h3>Road Maintenance</h3>
        <p>Report potholes, damaged roads, and unsafe public pathways for quick action.</p>
    </div>

    <div class="service-card">
        <i class="fa fa-tint"></i>
        <h3>Water Supply Issues</h3>
        <p>Register complaints related to water leakage, shortage, or contamination.</p>
    </div>

    <div class="service-card">
        <i class="fa fa-bolt"></i>
        <h3>Electricity Services</h3>
        <p>Submit issues like power cuts, damaged poles, and street light problems.</p>
    </div>

    <div class="service-card">
        <i class="fa fa-trash"></i>
        <h3>Garbage & Sanitation</h3>
        <p>Report garbage collection delays and sanitation-related problems.</p>
    </div>

    <div class="service-card">
        <i class="fa fa-hospital"></i>
        <h3>Public Health</h3>
        <p>Health hazards, mosquito breeding, and hygiene-related complaints.</p>
    </div>

    <div class="service-card">
        <i class="fa fa-shield-halved"></i>
        <h3>Public Safety</h3>
        <p>Unsafe areas, broken street lights, and general public safety concerns.</p>
    </div>

</div>

<!-- FOOTER -->
<div class="footer">
    © <?= date('Y') ?> Civic Issues Reporting System | All Rights Reserved
</div>

</body>
</html>
