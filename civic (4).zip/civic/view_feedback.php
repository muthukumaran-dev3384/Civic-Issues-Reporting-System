<?php
session_start();
include 'db.php';

/* ---------- ADMIN AUTH ---------- */
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

/* ---------- FETCH FEEDBACK ---------- */
$sql = "SELECT * FROM feedback ORDER BY id DESC";
$result = $conn->query($sql);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>User Feedback</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
/* RESET & BODY */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Arial, sans-serif;
}
body {
    background:linear-gradient(120deg,#e3f2fd,#f5f7fb); /* NOT CHANGED */
    min-height: 100vh;
    padding: 40px 20px;
    color: #1e293b;
}

/* CONTAINER */
.container {
    max-width: 1200px;
    margin: auto;
}

/* HEADER */
.header {
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    margin-bottom: 30px;
}
.header h1 {
    font-size: 28px;
    letter-spacing: 1px;
     color:#0f172a;
}
.btn-back {
    position: absolute;
    right: 0;
    top: 0;
    background: #ef4444;
    color: #fff;
    padding: 10px 16px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: 0.3s;
}
.btn-back:hover {
    background: #dc2626;
}

/* CARD */
.card {
    background: rgba(255,255,255,0.08);
    backdrop-filter: blur(15px);
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 15px 30px rgba(0,0,0,0.4);
}

/* TABLE WRAPPER */
.table-wrapper {
    overflow-x: auto;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
    border-radius: 12px;
    overflow: hidden;
    font-size: 14px;
}
th, td {
    padding: 14px 12px;
    text-align: left;
}
th {
    background: #0f172a;
    color: #f8fafc;
    font-weight: 600;
}
td {
    background: rgba(255,255,255,0.15);
    color: #1e293b;
}
tr:nth-child(even) td {
    background: rgba(255,255,255,0.10);
}
tr:hover td {
    background: rgba(37,99,235,0.2);
    transition: 0.2s;
}

/* EMPTY MESSAGE */
.empty {
    padding: 20px;
    text-align: center;
    font-weight: 600;
    color: #f8fafc;
    background: rgba(37,99,235,0.3);
    border-radius: 12px;
}

/* RESPONSIVE */
@media(max-width:768px){
    .header h1 {
        font-size: 22px;
    }
    .btn-back {
        top: -5px;
        right: 0;
        padding: 8px 12px;
        font-size: 13px;
    }
    th, td {
        font-size: 13px;
        padding: 10px;
    }
}
</style>
</head>

<body>
<div class="container">

    <!-- HEADER -->
    <div class="header">
        <h1><i class="fa fa-comments"></i> User Feedback</h1>
        <a href="admin_panel.php" class="btn-back"><i class="fa fa-arrow-left"></i> Back</a>
    </div>

    <!-- FEEDBACK CARD -->
    <div class="card">
        <?php if(!$result || $result->num_rows == 0){ ?>
            <div class="empty">No feedback available</div>
        <?php } else { ?>
        <div class="table-wrapper">
        <table>
            <tr>
                <th>ID</th>
                <th>User Email</th>
                <th>Feedback Message</th>
                <th>Rating</th>
                <th>Date</th>
            </tr>

            <?php while($f = $result->fetch_assoc()){ ?>
            <tr>
                <td><?= htmlspecialchars($f['id']) ?></td>
                <td><?= htmlspecialchars($f['user_email']) ?></td>
                <td><?= htmlspecialchars($f['message']) ?></td>
                <td><?= htmlspecialchars($f['rating']) ?>/5</td>
                <td><?= date('d-m-Y h:i A', strtotime($f['created_at'])) ?></td>
            </tr>
            <?php } ?>
        </table>
        </div>
        <?php } ?>
    </div>

</div>
</body>
</html>