<?php include 'db.php'; ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Officer Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
/* ---------------- GLOBAL ---------------- */
body {
    font-family: "Poppins", sans-serif;
    margin: 0;
    padding: 0;
    height: 100vh;
    background: #f1f5ff;
    display: flex;
    justify-content: center;
    align-items: center;
}

/* ---------------- LOGIN CARD ---------------- */
.container {
    width: 360px;
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(12px);
    padding: 30px;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.25);
    color: black;
    text-align: center;
    animation: floatUp 0.7s ease-in-out;
}

@keyframes floatUp {
    0% { opacity: 0; transform: translateY(20px); }
    100% { opacity: 1; transform: translateY(0); }
}

.container h2 {
    margin-bottom: 20px;
    font-weight: 700;
    letter-spacing: 1px;
}

/* ---------------- FORM ---------------- */
.card {
    display: flex;
    flex-direction: column;
    gap: 15px;  /* Perfect spacing between each field */
    margin-top: 10px;
    text-align: left;
}

.card label {
    font-size: 15px;
    font-weight: 500;
}

.card input, .card select {
    width: 100%;
    padding: 12px;
    border-radius: 10px;
    border: none;
    outline: none;
    font-size: 15px;
    background: rgba(255,255,255,0.88);
    box-sizing: border-box;
}

/* ---------------- BUTTON ---------------- */
.btn {
    width: 100%;
    padding: 12px;
    border-radius: 10px;
    margin-top: 10px;
    border: none;
    background: #002fff;
    color: white;
    font-size: 17px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.25s;
}

.btn:hover {
    background: #001fcc;
    transform: scale(1.05);
}

/* ---------------- DROPDOWN OPTIONS ---------------- */
select option {
    color: black;
}
</style>

</head>
<body>

<div class="container">
    <h2>👮 Officer Login</h2>

    <form method="POST" action="officer_check.php" class="card">

        <div>
            <label>Username:</label>
            <input type="text" name="username" required>
        </div>

        <div>
            <label>Password:</label>
            <input type="password" name="password" required>
        </div>

        <div>
            <label>Department:</label>
            <select name="department" required>
                <option value="" disabled selected>Select Department</option>
                <option value="road">🛣 Road</option>
                <option value="electricity">⚡ Electricity</option>
                <option value="water">💧 Water</option>
                <option value="garbage">🗑 Garbage</option>
            </select>
        </div>

        <button class="btn" type="submit">Login</button>

    </form>
</div>

</body>
</html>
