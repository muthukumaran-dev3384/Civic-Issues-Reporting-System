<?php

include 'db.php';

$error = '';
$postedEmail = '';

if (!isset($conn) || !($conn instanceof mysqli)) {
    die('Database connection not found. Check db.php.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $postedEmail = trim($_POST['email'] ?? '');

    if ($postedEmail === '') {
        $error = "Please enter email.";
    } elseif (!filter_var($postedEmail, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {

        $sql = "SELECT id FROM users WHERE email = ? LIMIT 1";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            $error = "Database error. Please try again later.";
        } else {
            $stmt->bind_param("s", $postedEmail);

            if (!$stmt->execute()) {
                $error = "Database error. Please try again later.";
                $stmt->close();
            } else {
                $stmt->store_result();

                if ($stmt->num_rows === 0) {
                    $stmt->close();
                    header("Location: signup.php?email=" . urlencode($postedEmail));
                    exit;
                } else {
                    $stmt->bind_result($userId);
                    $stmt->fetch();

                    $_SESSION['otp'] = random_int(100000, 999999);
                    $_SESSION['email'] = $postedEmail;
                    $_SESSION['user_id_temp'] = $userId;

                    $stmt->close();
                    header("Location: send_otp.php");
                    exit;
                }
            }
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Email Login | Civic</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
/* ---------- RESET ---------- */
*{
    box-sizing:border-box;
}

/* ---------- GLOBAL ---------- */
body{
    margin:0;
    font-family:"Segoe UI",Arial,sans-serif;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    background:linear-gradient(120deg,#e3f2fd,#f5f7fb);
}

/* ---------- CARD ---------- */
.login-box{
    width:380px;
    max-width:95%;
    background:rgba(255,255,255,.95);
    padding:32px;
    border-radius:18px;
    box-shadow:0 18px 40px rgba(0,0,0,.35);
    backdrop-filter:blur(8px);
}

/* ---------- HEADER ---------- */
.login-box h2{
    margin:0 0 22px;
    text-align:center;
    color:#0d47a1;
    font-size:24px;
}
.login-box h2 i{
    margin-right:8px;
}

/* ---------- ERROR ---------- */
.error{
    background:#ffe6e6;
    color:#b30000;
    padding:12px;
    border-radius:10px;
    margin-bottom:16px;
    text-align:center;
    font-size:14px;
}

/* ---------- FORM ---------- */
.form-group{
    position:relative;
    width:100%;
    margin-bottom:20px;
}

.form-group i{
    position:absolute;
    left:14px;
    top:50%;
    transform:translateY(-50%);
    color:#1976d2;
    font-size:16px;
}

.form-group input{
    width:100%;
    height:46px;
    padding:0 14px 0 44px;
    border-radius:10px;
    border:1px solid #c7d2df;
    font-size:15px;
    outline:none;
    transition:.2s;
    background:#fff;
}

.form-group input:focus{
    border-color:#1976d2;
    box-shadow:0 0 0 3px rgba(25,118,210,.15);
}

/* ---------- BUTTON ---------- */
button{
    width:100%;
    height:48px;
    border:none;
    border-radius:12px;
    font-size:16px;
    font-weight:600;
    background:linear-gradient(135deg,#0d47a1,#1976d2);
    color:#fff;
    cursor:pointer;
    transition:.25s;
}

button i{
    margin-right:6px;
}

button:hover{
    transform:translateY(-2px);
    box-shadow:0 8px 20px rgba(0,0,0,.3);
}
.back
{
    padding:12px;
    align:left;
    width:40%;
    height:48px;
    color:#fff;
    
}
.btn.gray{color:white}

/* ---------- FOOT NOTE ---------- */
.note{
    margin-top:18px;
    text-align:center;
    font-size:13px;
    color:#555;
}
</style>
</head>

<body>

<div class="login-box">
    <h2><i class="fa fa-envelope"></i>Email Login</h2>

    <?php if ($error !== ''): ?>
        <div class="error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <i class="fa fa-at"></i>
            <input type="email" name="email" placeholder="Enter your email" required
                   value="<?= htmlspecialchars($postedEmail, ENT_QUOTES, 'UTF-8'); ?>">
        </div>

        <button type="submit">
            <i class="fa fa-paper-plane"></i> Send OTP
        </button>
    </form>
    <div class="back">
<button><a href="user_dashboard.php" class="btn gray">⬅ Back</a></button>
</div>
    <div class="note">
        Secure login using One-Time Password
    </div>
</div>

</body>
</html>
