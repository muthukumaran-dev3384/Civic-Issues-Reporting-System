<?php
session_start();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $enteredOtp = trim($_POST['otp']);

    if (!isset($_SESSION['otp']) || !isset($_SESSION['user_id_temp'])) {
        $error = "Session expired. Please login again.";
    } elseif ($enteredOtp == $_SESSION['otp']) {

        // OTP SUCCESS → login permanently
        $_SESSION['user_id'] = $_SESSION['user_id_temp'];
        $_SESSION['email'] = $_SESSION['email'];

        unset($_SESSION['otp']);
        unset($_SESSION['user_id_temp']);

        header("Location: index.php");
        exit;
    } else {
        $error = "Invalid OTP!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Verify OTP</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body{
    font-family:Segoe UI,Arial,sans-serif;
    background:linear-gradient(120deg,#e3f2fd,#f5f7fb);
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

.box{
    background:#fff;
    padding:30px 28px;
    border-radius:14px;
    width:360px;
    box-shadow:0 8px 25px rgba(0,0,0,.2);
    text-align:center;
}

.box h2{
    margin:0;
    color:#0d47a1;
}
.box i{
    font-size:40px;
    color:#1976d2;
    margin-bottom:10px;
}

.otp-inputs{
    display:flex;
    justify-content:space-between;
    margin:20px 0;
}

.otp-inputs input{
    width:45px;
    height:50px;
    font-size:22px;
    text-align:center;
    border:1px solid #ccc;
    border-radius:8px;
    outline:none;
    transition:.2s;
}
.otp-inputs input:focus{
    border-color:#1976d2;
    box-shadow:0 0 4px #1976d2;
}

button{
    width:100%;
    padding:12px;
    background:#1976d2;
    border:none;
    border-radius:8px;
    color:#fff;
    font-size:16px;
    cursor:pointer;
}
button:hover{background:#0d47a1}

.timer{
    margin-top:12px;
    font-size:14px;
    color:#555;
}

.error{
    background:#ffe6e6;
    padding:10px;
    border-radius:8px;
    color:#c00;
    margin-bottom:12px;
}
</style>
</head>

<body>

<div class="box">
    <i class="fa fa-lock"></i>
    <h2>OTP Verification</h2>
    <p>Enter the 6-digit OTP sent to your email</p>

    <?php if ($error !== '') echo "<div class='error'>$error</div>"; ?>

    <form method="POST" onsubmit="combineOtp()">
        <div class="otp-inputs">
            <input type="text" maxlength="1" oninput="moveNext(this,1)">
            <input type="text" maxlength="1" oninput="moveNext(this,2)">
            <input type="text" maxlength="1" oninput="moveNext(this,3)">
            <input type="text" maxlength="1" oninput="moveNext(this,4)">
            <input type="text" maxlength="1" oninput="moveNext(this,5)">
            <input type="text" maxlength="1">
        </div>

        <input type="hidden" name="otp" id="otp">

        <button type="submit">
            <i class="fa fa-check-circle"></i> Verify OTP
        </button>
    </form>

    <div class="timer">
        <i class="fa fa-clock"></i> OTP expires in <span id="time">02:00</span>
    </div>
</div>

<script>
/* AUTO MOVE */
function moveNext(el, index){
    if(el.value.length === 1){
        const next = document.querySelectorAll('.otp-inputs input')[index];
        if(next) next.focus();
    }
}

/* COMBINE OTP */
function combineOtp(){
    let otp = '';
    document.querySelectorAll('.otp-inputs input').forEach(i => otp += i.value);
    document.getElementById('otp').value = otp;
}

/* TIMER */
let time = 120;
setInterval(()=>{
    if(time <= 0) return;
    time--;
    let m = String(Math.floor(time/60)).padStart(2,'0');
    let s = String(time%60).padStart(2,'0');
    document.getElementById('time').innerText = m+":"+s;
},1000);
</script>

</body>
</html>
