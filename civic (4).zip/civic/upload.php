<?php

/* ================= SESSION ================= */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ================= DATABASE ================= */
include_once "db.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Invalid request");
}

/* ================= INPUTS ================= */
$category    = strtolower($_POST['category'] ?? '');
$photo       = $_POST['photo'] ?? '';
$latitude    = $_POST['latitude'] ?? null;
$longitude   = $_POST['longitude'] ?? null;
$city        = $_POST['city'] ?? '';
$area        = $_POST['area'] ?? '';
$road        = $_POST['road'] ?? '';
$user_phone  = $_POST['phone'] ?? '';
$description = $_POST['description'] ?? '';
$priority    = $_POST['priority'] ?? 'Medium';
$created_at  = date('Y-m-d H:i:s');
$status      = "Pending";

/* ================= CATEGORY VALIDATION ================= */
$allowedCategories = [
    'road',
    'electricity',
    'water',
    'garbage',
    'streetlight',
    'drainage'
];

if (!in_array($category, $allowedCategories)) {
    die("Invalid complaint category");
}

if (!$photo) {
    die("Photo missing");
}

/* ================= GENERATE COMPLAINT CODE ================= */
$complaint_code = generateComplaintCode($conn, $category);

/* ================= IMAGE SAVE ================= */
$photo = preg_replace('#^data:image/\w+;base64,#i', '', $photo);
$imageData = base64_decode($photo);

$uploadDir = "uploads/";

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$filePath = $uploadDir . $complaint_code . ".jpg";
file_put_contents($filePath, $imageData);

/* ================= USER EMAIL ================= */
$user_email = $_SESSION['email'] ?? null;

/* ================= INSERT COMPLAINT ================= */
$sql = "
INSERT INTO complaints (
    complaint_code,
    category,
    photo_path,
    latitude,
    longitude,
    city,
    area,
    road,
    user_phone,
    user_email,
    description,
    priority,
    date_time,
    status
) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Prepare Failed: " . $conn->error);
}

$stmt->bind_param(
    "ssssddssssssss",
    $complaint_code,
    $category,
    $filePath,
    $latitude,
    $longitude,
    $city,
    $area,
    $road,
    $user_phone,
    $user_email,
    $description,
    $priority,
    $created_at,
    $status
);

if ($stmt->execute()) {

echo "
<!DOCTYPE html>
<html>
<head>

<title>Complaint Submitted</title>

<meta http-equiv='refresh' content='30;url=user_index.php'>

<link href='https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap' rel='stylesheet'>

<style>

body{
font-family:Poppins;
background:linear-gradient(120deg,#e3f2fd,#f5f7fb);
height:100vh;
display:flex;
justify-content:center;
align-items:center;
}

.card{
background:white;
padding:40px;
width:420px;
border-radius:12px;
text-align:center;
box-shadow:0 10px 25px rgba(0,0,0,0.2);
}

.success{
font-size:60px;
}

h2{
color:#28a745;
}

.info{
text-align:left;
margin-top:20px;
font-size:16px;
}

.info p{
margin:8px 0;
}

.btn{
display:inline-block;
margin-top:20px;
padding:10px 20px;
background:#007bff;
color:white;
text-decoration:none;
border-radius:6px;
}

.btn:hover{
background:#0056b3;
}

.timer{
margin-top:15px;
color:#555;
font-size:14px;
}

</style>

</head>

<body>

<div class='card'>

<div class='success'>✅</div>

<h2>Complaint Submitted Successfully</h2>

<div class='info'>
<p><b>Complaint ID :</b> $complaint_code</p>
<p><b>Department :</b> ".ucfirst($category)."</p>
<p><b>Status :</b> Pending</p>
<p><b>Priority :</b> $priority</p>
</div>

<div class='timer'>
You will be redirected to dashboard in <b>30 seconds</b>
</div>

<a class='btn' href='index.php'>Go Now</a>

</div>

</body>
</html>
";

} else {

echo "Insert Error: " . $stmt->error;

}

?>