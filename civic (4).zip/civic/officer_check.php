<?php
// officer_check.php - validate officer credentials and department
include 'db.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: officer_login.php'); exit; }
$username = $_POST['username']; $password = $_POST['password']; $department = $_POST['department'];
$stmt = $conn->prepare('SELECT id, name, department, password FROM officers WHERE username = ? AND department = ?');
$stmt->bind_param('ss', $username, $department);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows === 0) { die('Invalid login or wrong department'); }
$off = $res->fetch_assoc();
// Note: demo uses SHA2. In production use password_hash().
if (hash('sha256', $password) !== $off['password']) { die('Invalid login'); }
$_SESSION['officer_id'] = $off['id']; $_SESSION['officer_dept'] = $off['department']; $_SESSION['officer_name'] = $off['name'];
header('Location: officer_dashboard.php');
exit;
?>