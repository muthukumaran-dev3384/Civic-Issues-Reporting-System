<?php
include "db.php";

/* ---------- SAFE COUNT FUNCTION ---------- */
function getCount($conn, $sql){
    $q = mysqli_query($conn, $sql);
    if(!$q){
        return 0;
    }
    $r = mysqli_fetch_assoc($q);
    return $r['c'] ?? 0;
}

/* ---------- OVERALL STATS ---------- */
$total    = getCount($conn,"SELECT COUNT(*) c FROM complaints");
$pending  = getCount($conn,"SELECT COUNT(*) c FROM complaints WHERE status='pending'");
$resolved = getCount($conn,"SELECT COUNT(*) c FROM complaints WHERE status='resolved'");

/* ---------- MOST FREQUENT COMPLAINTS ---------- */
$categories = [
    "road"        => ["Road","fa-road"],
    "electricity" => ["Electricity","fa-bolt"],
    "water"       => ["Water","fa-tint"],
    "garbage"     => ["Garbage","fa-trash"],
];

$freqData = [];

foreach($categories as $key=>$data){
    $freqData[] = [
        "name"     => $data[0],
        "icon"     => $data[1],
        "total"    => getCount($conn,"SELECT COUNT(*) c FROM complaints WHERE category='$key'"),
        "pending"  => getCount($conn,"SELECT COUNT(*) c FROM complaints WHERE category='$key' AND status='pending'"),
        "resolved" => getCount($conn,"SELECT COUNT(*) c FROM complaints WHERE category='$key' AND status='resolved'")
    ];
}

usort($freqData, fn($a,$b)=>$b['total']<=>$a['total']);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title> Civic Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
/* ---------- GLOBAL ---------- */
body{
    margin:0;
    font-family:"Segoe UI",Arial,sans-serif;
    background: url('img/img1.jpg') no-repeat center center fixed;
    background-size: cover;
}

/* ---------- HEADER ---------- */
.header{
    background:linear-gradient(90deg,#0d47a1,#1976d2);
    color:#fff;
    padding:10px 16px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 6px 18px rgba(0,0,0,.3);
}
.header a{
    color:#fff;
    text-decoration:none;
    background:rgba(255, 255, 255, 0.29);
    padding:8px 16px;
    border-radius:8px;
    margin-left:10px;
    font-weight:600;
    transition:.2s;
}
.header a:hover{
    background:rgba(255,255,255,.35);
}

/* ---------- MAIN LAYOUT ---------- */
.main{
    display:flex;
    gap:30px;
    padding:30px;
}
.left{flex:1}

/* ---------- STATS CARDS ---------- */
.stats{
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:30px;
}

.stat{
    background:rgba(255,255,255,.92);
    padding:28px;
    border-radius:16px;
    box-shadow:0 10px 28px rgba(0,0,0,.25);
    position:relative;
    backdrop-filter:blur(6px);
    transition:.25s;
}
.stat:hover{
    transform:translateY(-4px);
}

.stat i{
    position:absolute;
    right:18px;
    top:22px;
    font-size:34px;
    padding:14px;
    border-radius:50%;
    color:#fff;
}
.stat.resolved i{background:linear-gradient(135deg,#2e7d32,#66bb6a);}
.stat.pending i{background:linear-gradient(135deg,#f57c00,#ffb74d);}
.stat.total-card i{background:linear-gradient(135deg,#0d47a1,#42a5f5);}

.stat h2{
    margin:0;
    font-size:30px;
    font-weight:700;
    color:#0d47a1;
}
.stat p{
    margin-top:6px;
    font-size:14px;
    color:#444;
}

.stat.resolved{border-left:6px solid #2e7d32}
.stat.pending{border-left:6px solid #f57c00}
.stat.total-card{grid-column:1; border-left:6px solid #0d47a1;}

/* ---------- RIGHT PANEL FREQUENT COMPLAINTS ---------- */
.right{
    width:300px;
    position:sticky;
    top:90px;
    height:50vh;
    background:rgba(255,255,255,.95);
    border-radius:18px;
    box-shadow:0 12px 28px rgba(0,0,0,.35);
    overflow:hidden;
    backdrop-filter:blur(6px);
}
.right h3{
    background:linear-gradient(90deg,#0d47a1,#1976d2);
    color:#fff;
    margin:0;
    padding:15px;
    font-size:15px;
}
.freq-scroll{
    padding:12px;
    height:calc(80% - 25px);
    overflow-y:auto;
}
.freq-card{
    display:flex;
    gap:10px;
    align-items:flex-start;
    background:#f8faff;
    padding:10px;
    border-radius:10px;
    margin-bottom:10px;
    border-left:4px solid #1976d2;
    box-shadow:0 4px 10px rgba(0,0,0,.12);
}
.freq-card i{
    font-size:18px;
    color:#1976d2;
    margin-top:2px;
}
.freq-card h4{margin:0; font-size:14px;}
.freq-card small{display:block; font-size:12px; color:#555;}

/* ---------- PREMIUM FEATURE STATS CARDS ---------- */
.features-container{
    display:grid;
     background: #739bc4;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
    padding:30px;
}
.stats-card{
    background:#fff;
    border-radius:16px;
    padding:20px;
    text-align:center;
    box-shadow:0 12px 28px rgba(0,0,0,.15);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.stats-card:hover{
    transform:translateY(-8px);
    box-shadow:0 25px 50px rgba(0,0,0,.25);
}
.icon-wrapper{
    width:70px;
    height:70px;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
    margin:auto;
    font-size:28px;
    color:#fff;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.bg-gradient-primary{background:linear-gradient(135deg,#0d47a1,#42a5f5);}
.bg-gradient-info{background:linear-gradient(135deg,#0288d1,#26c6da);}
.bg-gradient-warning{background:linear-gradient(135deg,#f57c00,#ffb74d);}
.bg-gradient-danger{background:linear-gradient(135deg,#c62828,#ef5350);}
.stats-card:hover .icon-wrapper{
    transform: scale(1.15);
    box-shadow:0 8px 20px rgba(0,0,0,.25);
}
.stats-card h5{font-size:16px; font-weight:700; margin-bottom:6px; color:#111827;}
.stats-card p{font-size:13px; color:#6b7280; margin-bottom:8px;}
.stat-number{font-size:22px; font-weight:700;}

/* ---------- FOOTER ---------- */
.footer {
    background: #7c7c7c;
    color: #f8fafc;
    padding: 25px 20px;
    text-align: center;
    font-size: 14px;
    margin-top: 30px;
    border-radius: 12px;
}
.footer-container {display:flex;flex-wrap:wrap;justify-content:space-between;max-width:1100px;margin:auto;gap:20px;}
.footer h4 {margin-bottom:10px;font-size:16px;font-weight:600;}
.footer p, .footer li, .footer a {margin:5px 0;color:#f8fafc;text-decoration:none;}
.footer a:hover {text-decoration:underline;}
.footer ul {list-style:none;padding:0;}
.footer-left, .footer-center, .footer-right {flex:1 1 200px;}
@media(max-width:900px){
    .main{flex-direction:column}
    .right{width:100%;height:auto;position:relative;}
}
@media(max-width:768px){
    .stats{grid-template-columns:1fr;}
}
</style>
</head>

<body>

<div class="header">
    <h2><i class="fa fa-city"></i> Civic Dashboard</h2>
    <div>
        <a href="index.php"><i class="fa fa-plus"></i> Add Complaint</a>
        <a href="track_complaint.php"><i class="fa fa-search"></i> Check Status</a>
        <a href="feedback.php"><i class="fa fa-comment-dots"></i> Feedback</a>
        <a href="our_services.php"><i class="fa fa-handshake"></i> Our Services</a>
    </div>
</div>

<div class="main">

<div class="left">
    <div class="stats">
        <div class="stat resolved">
            <i class="fa fa-check-circle"></i>
            <h2><?= $resolved ?></h2>
            <p>Resolved Complaints</p>
        </div>

        <div class="stat pending">
            <i class="fa fa-clock"></i>
            <h2><?= $pending ?></h2>
            <p>Pending Complaints</p>
        </div>

        <div class="stat total-card">
            <i class="fa fa-layer-group"></i>
            <h2><?= $total ?></h2>
            <p>Total Complaints</p>
        </div>
    </div>
</div>

<div class="right">
    <h3><i class="fa fa-chart-bar"></i> Most Frequent Complaints</h3>
    <div class="freq-scroll">
        <?php foreach($freqData as $f): ?>
        <div class="freq-card">
            <i class="fa <?= $f['icon'] ?>"></i>
            <div>
                <h4><?= $f['name'] ?></h4>
                <small>Total: <?= $f['total'] ?></small>
                <small>Pending: <?= $f['pending'] ?> | Resolved: <?= $f['resolved'] ?></small>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

</div>
<br>
<br>
<br>
<!-- ---------- FEATURE STATS / PREMIUM SMALL CARDS ---------- -->

<section class="features-container">

    <div class="stats-card">
        <div class="icon-wrapper bg-gradient-primary">
            <i class="fas fa-plus-circle"></i>
        </div>
        <h5>Easy Complaint Submission</h5>
        <p class="text-muted small">
            Citizens can quickly register complaints with category and description.
        </p>
    </div>

    <div class="stats-card">
        <div class="icon-wrapper bg-gradient-info">
            <i class="fas fa-search"></i>
        </div>
        <h5>Track Complaint Status</h5>
        <p class="text-muted small">
            Users can track complaint progress using their complaint ID.
        </p>
    </div>

    <div class="stats-card">
        <div class="icon-wrapper bg-gradient-warning">
            <i class="fas fa-user-shield"></i>
        </div>
        <h5>Admin & Officer Panel</h5>
        <p class="text-muted small">
            Admin and officers can manage and officer update complaint statuses.
        </p>
    </div>

    <div class="stats-card">
        <div class="icon-wrapper bg-gradient-danger">
            <i class="fas fa-chart-line"></i>
        </div>
        <h5>Dashboard Analytics</h5>
        <p class="text-muted small">
            Real-time statistics of total, pending, and resolved complaints.
        </p>
    </div>

</section>

<!-- FOOTER -->
<div class="footer">
    <div class="footer-container">
        <div class="footer-left">
            <h4>Civic Issue Reporting System</h4>
            <p>© <?= date('Y') ?> All Rights Reserved.</p>
        </div>
        <div class="footer-center">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="admin_login.php">Admin Login</a></li>
                <li><a href="officer_login.php">Officer Login</a></li>
                <li><a href="index.php">Home</a></li>
            </ul>
        </div>
        <div class="footer-right">
            <h4>Contact</h4>
            <p>Email: support@smartcivic.com</p>
            <p>Phone: +1 234 567 890</p>
        </div>
    </div>
</div>

</body>
</html>