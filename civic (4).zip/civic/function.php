<?php
function generateComplaintID($category, $conn) {

    // Prefix map
    $prefix = [
        'road'        => 'TN-RD',
        'water'       => 'TN-WD',
        'electricity' => 'TN-EB'
    ];

    $pre = $prefix[$category];

    // Find last complaint of same category
    $stmt = $conn->prepare("SELECT complaint_id FROM complaints WHERE complaint_id LIKE ? ORDER BY complaint_id DESC LIMIT 1");
    $like = $pre . "%";
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $lastNumber = intval(substr($row['complaint_id'], -3)); 
        $newNumber = str_pad($lastNumber + 1, 3, "0", STR_PAD_LEFT);
    } else {
        $newNumber = "001";
    }

    return $pre . $newNumber;
}
