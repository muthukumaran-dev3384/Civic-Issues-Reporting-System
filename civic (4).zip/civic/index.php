<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login_process.php");
    exit;
}

$userName  = $_SESSION['user_name'] ?? "User";
$userEmail = $_SESSION['email'] ?? "No email";
$avatarLetter = strtoupper(substr($userName, 0, 1));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Civic Issue Portal — Dashboard</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root{
  --primary:#0f62fe;
  --danger:#ef4444;
  --muted:#6b7280;
  --radius:16px;
  --shadow:0 14px 40px rgba(12,32,63,0.15);
}

*{box-sizing:border-box}

body{
  margin:0;
  font-family:"Inter",sans-serif;
  background:#f4f7ff;
}

/* ===== LAYOUT ===== */
.layout{
  display:flex;
  min-height:100vh;
}

/* ===== SIDEBAR ===== */
.sidebar{
  width:260px;
  background:#fff;
  padding:25px 20px;
  box-shadow:4px 0 20px rgba(0,0,0,0.08);
  position:fixed;
  top:0;
  left:0;
  bottom:0;
}

.user-info{
  display:flex;
  align-items:center;
  gap:15px;
  margin-bottom:30px;
}

.avatar{
  width:55px;
  height:55px;
  border-radius:16px;
  background:linear-gradient(135deg,#7c3aed,#0f62fe);
  color:#fff;
  font-size:24px;
  font-weight:700;
  display:flex;
  align-items:center;
  justify-content:center;
}

.user-name{
  font-weight:700;
}

.user-email{
  font-size:13px;
  color:var(--muted);
}

/* Sidebar Buttons */
.sidebar button{
  width:100%;
  padding:12px;
  margin-bottom:12px;
  border-radius:10px;
  border:none;
  font-size:15px;
  font-weight:600;
  cursor:pointer;
  display:flex;
  align-items:center;
  gap:10px;
}

.btn-blue{background:var(--primary);color:#fff;}
.btn-red{background:var(--danger);color:#fff;}

/* ===== MAIN CONTENT ===== */
.main{
  margin-left:260px;
  padding:35px;
  width:100%;
}

.page-title{
  font-size:22px;
  font-weight:700;
  margin-bottom:25px;
  display:flex;
  align-items:center;
  gap:10px;
}

/* GRID */
.grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(260px,1fr));
  gap:28px;
}

/* CARD */
.card-tile{
  background:#fff;
  padding:26px;
  border-radius:var(--radius);
  box-shadow:var(--shadow);
  cursor:pointer;
  transition:.25s;
  display:flex;
  align-items:center;
  gap:18px;
}

.card-tile:hover{
  transform:translateY(-6px);
}

.card-icon{
  width:60px;
  height:60px;
  border-radius:14px;
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:26px;
  color:#fff;
}

.road{background:#0f62fe}
.electricity{background:#f59e0b}
.water{background:#0ea5e9}
.garbage{background:#22c55e}
.streetlight{background:#a855f7}

.tile-title{
  font-size:18px;
  font-weight:700;
}

.tile-desc{
  font-size:14px;
  color:var(--muted);
}

.arrow{
  margin-left:auto;
  color:#9ca3af;
}

/* FOOTER */
.footer{
  margin-top:40px;
  text-align:center;
  color:#6b7280;
  font-size:14px;
}
</style>
</head>

<body>

<div class="layout">

  <!-- ===== SIDEBAR ===== -->
  <aside class="sidebar">

    <div class="user-info">
      <div class="avatar"><?php echo $avatarLetter; ?></div>
      <div>
        <div class="user-name"><?php echo htmlspecialchars($userName); ?></div>
        <div class="user-email"><?php echo htmlspecialchars($userEmail); ?></div>
      </div>
    </div>

    <button class="btn-blue" onclick="location.href='my_complaint.php'">
      <i class="fa-solid fa-clipboard-list"></i> My Complaints
    </button>

    <button class="btn-red" onclick="location.href='logout.php'">
      <i class="fa-solid fa-right-from-bracket"></i> Logout
    </button>

  </aside>

  <!-- ===== MAIN ===== -->
  <main class="main">

    <div class="page-title">
      <i class="fa-solid fa-table-cells-large"></i>
      Complaint Categories
    </div>

    <div class="grid">

      <div class="card-tile" onclick="location.href='camera_report.php?cat=road'">
        <div class="card-icon road"><i class="fa-solid fa-road"></i></div>
        <div>
          <div class="tile-title">Road Damage</div>
          <div class="tile-desc">Potholes, cracks</div>
        </div>
        <i class="fa-solid fa-arrow-right arrow"></i>
      </div>

      <div class="card-tile" onclick="location.href='camera_report.php?cat=electricity'">
        <div class="card-icon electricity"><i class="fa-solid fa-bolt"></i></div>
        <div>
          <div class="tile-title">Electricity</div>
          <div class="tile-desc">Outage, wiring</div>
        </div>
        <i class="fa-solid fa-arrow-right arrow"></i>
      </div>

      <div class="card-tile" onclick="location.href='camera_report.php?cat=water'">
        <div class="card-icon water"><i class="fa-solid fa-droplet"></i></div>
        <div>
          <div class="tile-title">Water Supply</div>
          <div class="tile-desc">Leakage, pressure</div>
        </div>
        <i class="fa-solid fa-arrow-right arrow"></i>
      </div>

      <div class="card-tile" onclick="location.href='camera_report.php?cat=garbage'">
        <div class="card-icon garbage"><i class="fa-solid fa-trash"></i></div>
        <div>
          <div class="tile-title">Garbage</div>
          <div class="tile-desc">Waste issues</div>
        </div>
        <i class="fa-solid fa-arrow-right arrow"></i>
      </div>

    

    </div>

    <div class="footer">
      © <?php echo date("Y"); ?> Civic Issue Reporting System
    </div>

  </main>

</div>

</body>
</html>
