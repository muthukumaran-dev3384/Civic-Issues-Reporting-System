<?php
include 'db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['officer_id'])) {
    header('Location: officer_login.php');
    exit;
}

$dept = $_SESSION['officer_dept'];
$officer_name = $_SESSION['officer_name'];

function h($s){
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

/* ---------------- DASHBOARD COUNTS ---------------- */
$countSql = "
SELECT 
    COUNT(*) AS total,
    SUM(CASE WHEN status='Pending' THEN 1 ELSE 0 END) AS pending,
    SUM(CASE WHEN status='Resolved' THEN 1 ELSE 0 END) AS resolved,
    SUM(CASE WHEN status='In Progress' THEN 1 ELSE 0 END) AS progress
FROM complaints
WHERE LOWER(category)=LOWER(?)
";

$cstmt = $conn->prepare($countSql);
if (!$cstmt) {
    die("Prepare Failed (Counts): " . $conn->error);
}

$cstmt->bind_param("s", $dept);
$cstmt->execute();
$counts = $cstmt->get_result()->fetch_assoc();
$cstmt->close();

/* Avoid NULL values */
$counts['total'] = $counts['total'] ?? 0;
$counts['pending'] = $counts['pending'] ?? 0;
$counts['resolved'] = $counts['resolved'] ?? 0;
$counts['progress'] = $counts['progress'] ?? 0;
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Officer Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<!-- Font Awesome Icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    background:linear-gradient(120deg,#e3f2fd,#f5f7fb); /* NOT CHANGED */
    display:flex;
    min-height:100vh;
}

/* ===== SIDEBAR ===== */
.sidebar{
    width:260px;
    background:#0f172a;
    color:#fff;
    padding:30px 20px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
    box-shadow:4px 0 15px rgba(0,0,0,.1);
}

.sidebar h2{
    text-align:center;
    margin-bottom:40px;
    font-size:22px;
    font-weight:600;
    letter-spacing:1px;
}

.sidebar a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 18px;
    margin-bottom:15px;
    background:#1e293b;
    color:#fff;
    text-decoration:none;
    border-radius:12px;
    font-weight:500;
    transition:all .3s ease;
}

.sidebar a i{
    width:20px;
    text-align:center;
}

.sidebar a:hover{
    background:#2563eb;
    transform:translateX(6px);
}

.sidebar .active{
    background:#2563eb;
}

.logout{
    background:#dc2626 !important;
}

.logout:hover{
    background:#b91c1c !important;
}

/* ===== MAIN ===== */
.main{
    flex:1;
    padding:40px;
}

/* ===== HEADER CARD ===== */
.header{
    background:#fff;
    padding:25px 30px;
    border-radius:18px;
    box-shadow:0 10px 25px rgba(0,0,0,.08);
    margin-bottom:35px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.header h2{
    font-size:22px;
    font-weight:600;
    color:#0f172a;
}

.header i{
    font-size:26px;
    color:#2563eb;
}

/* ===== STATS ===== */
.stats{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
    gap:25px;
}

.stat{
    background:#fff;
    padding:30px 25px;
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,.08);
    transition:all .3s ease;
    position:relative;
    overflow:hidden;
}

.stat:hover{
    transform:translateY(-8px);
    box-shadow:0 18px 35px rgba(0,0,0,.12);
}

.stat .icon{
    font-size:30px;
    margin-bottom:15px;
}

.stat p{
    font-size:14px;
    font-weight:600;
    color:#64748b;
    margin-bottom:8px;
}

.stat h3{
    font-size:34px;
    font-weight:700;
    color:#0f172a;
}

/* Top colored line */
.stat::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:5px;
}

.stat.total::before{ background:#2563eb; }
.stat.pending::before{ background:#f59e0b; }
.stat.progress::before{ background:#0ea5e9; }
.stat.resolved::before{ background:#22c55e; }

.stat.total .icon{ color:#2563eb; }
.stat.pending .icon{ color:#f59e0b; }
.stat.progress .icon{ color:#0ea5e9; }
.stat.resolved .icon{ color:#22c55e; }

/* ===== RESPONSIVE ===== */
@media(max-width:900px){
    .sidebar{
        display:none;
    }
    .main{
        padding:20px;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div>
        <h2><i class="fa-solid fa-user-shield"></i> Officer Panel</h2>
        <a href="officer_dashboard.php" class="active">
            <i class="fa-solid fa-chart-line"></i> Dashboard
        </a>
        <a href="officer_complients.php">
            <i class="fa-solid fa-file-lines"></i> Complaints
        </a>
    </div>

    <a href="officer_logout.php" class="logout">
        <i class="fa-solid fa-right-from-bracket"></i> Logout
    </a>
</div>

<!-- MAIN -->
<div class="main">

<div class="header">
    <h2>
        Welcome, <?= h($officer_name) ?>  
        – <?= ucfirst(h($dept)) ?> Department
    </h2>
    <i class="fa-solid fa-bell"></i>
</div>

<!-- STATS -->
<div class="stats">

    <div class="stat total">
        <div class="icon"><i class="fa-solid fa-folder-open"></i></div>
        <p>Total Complaints</p>
        <h3><?= $counts['total'] ?></h3>
    </div>

    <div class="stat pending">
        <div class="icon"><i class="fa-solid fa-hourglass-half"></i></div>
        <p>Pending</p>
        <h3><?= $counts['pending'] ?></h3>
    </div>

    <div class="stat progress">
        <div class="icon"><i class="fa-solid fa-spinner"></i></div>
        <p>In Progress</p>
        <h3><?= $counts['progress'] ?></h3>
    </div>

    <div class="stat resolved">
        <div class="icon"><i class="fa-solid fa-circle-check"></i></div>
        <p>Resolved</p>
        <h3><?= $counts['resolved'] ?></h3>
    </div>

</div>

</div>
</body>
</html>