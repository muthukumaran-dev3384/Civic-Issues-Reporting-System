<?php
session_start();
include 'db.php';

if (!isset($_SESSION['officer_id'])) {
    die("Unauthorized");
}

$id     = (int)$_POST['complaint_id'];
$status = $_POST['status'];

$stmt = $conn->prepare("
    UPDATE complaints
    SET status = ?, updated_at = NOW()
    WHERE id = ?
");
$stmt->bind_param("si", $status, $id);
$stmt->execute();

header("Location: officer_complients.php");
