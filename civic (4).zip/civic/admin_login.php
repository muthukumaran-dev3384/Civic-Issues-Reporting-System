<?php
session_start();
include 'db.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if ($username === '' || $password === '') {
        $error = "All fields are required";
    } else {

        $stmt = $conn->prepare(
            "SELECT id, username, password 
             FROM admins 
             WHERE username = ? 
             LIMIT 1"
        );
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows === 0) {
            $error = "Invalid Username or Password";
        } else {

            $admin = $res->fetch_assoc();

            /* ✅ SHA-256 PASSWORD CHECK (MATCHES DB) */
            if (hash('sha256', $password) !== $admin['password']) {
                $error = "Invalid Username or Password";
            } else {

                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_username'] = $admin['username'];

                header("Location: admin_panel.php");
                exit;
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Admin Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
/* RESET & BODY */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Poppins', Arial, sans-serif;
}

body {
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
     background:linear-gradient(120deg,#e3f2fd,#f5f7fb); 
}

/* CONTAINER */
.container {
    width: 100%;
    max-width: 400px;
    padding: 20px;
}

/* CARD */
.card {
    background: rgba(206, 160, 160, 0.1);
    backdrop-filter: blur(15px);
    padding: 35px 30px;
    border-radius: 20px;
    box-shadow: 0 25px 50px rgba(0,0,0,0.4);
    text-align: center;
}

/* HEADER */
h2 {
    margin-bottom: 25px;
    color:#0f172a;
    font-size: 26px;
}

/* ERROR MESSAGE */
.error {
    background: rgba(248, 113, 113,0.2);
    color: #b91c1c;
    padding: 12px;
    border-radius: 12px;
    margin-bottom: 20px;
    font-weight: 600;
    text-align: center;
}

/* FORM ELEMENTS */
form {
    display: flex;
    flex-direction: column;
    gap: 15px;
    text-align: left;
}

label {
    font-weight: 600;
   color:#0f172a;
    margin-bottom: 5px;
}

input {
    width: 100%;
    padding: 12px 15px;
    border-radius: 12px;
    border: 1px solid rgba(3, 3, 3, 0.3);
    outline: none;
    font-size: 14px;
    background: rgba(255,255,255,0.15);
    color: #1e293b;
    transition: 0.3s;
}

input:focus {
    border-color: #2563eb;
    background: rgba(255,255,255,0.25);
}

/* LOGIN BUTTON */
.btn {
    width: 100%;
    padding: 14px;
    background: #2563eb;
    border: none;
    border-radius: 12px;
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
}

.btn:hover {
    background: #1d4ed8;
}

/* RESPONSIVE */
@media(max-width:480px){
    .card {
        padding: 30px 20px;
    }
    h2 {
        font-size: 22px;
    }
}
</style>
</head>

<body>
<div class="container">
    <div class="card">

        <h2><i class="fa fa-lock"></i> Admin Login</h2>

        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" required>

            <label for="password">Password</label>
            <input type="password" name="password" id="password" required>

            <button class="btn" type="submit">Login</button>
        </form>

    </div>
</div>
</body>
</html>