<?php
include 'db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ---------- ADMIN AUTH ---------- */
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

/* ---------- SAFE COUNT FUNCTION ---------- */
function getCount($conn, $sql) {
    $res = $conn->query($sql);
    if ($res && $row = $res->fetch_assoc()) {
        return $row['c'];
    }
    return 0;
}

/* ---------- COUNTS ---------- */
$totalOfficers   = getCount($conn, "SELECT COUNT(*) c FROM officers");
$totalComplaints = getCount($conn, "SELECT COUNT(*) c FROM complaints");
$totalFeedback   = getCount($conn, "SELECT COUNT(*) c FROM feedback");

$pending   = getCount($conn, "SELECT COUNT(*) c FROM complaints WHERE status='Pending'");
$processed = getCount($conn, "SELECT COUNT(*) c FROM complaints WHERE status='In Progress'");
$resolved  = getCount($conn, "SELECT COUNT(*) c FROM complaints WHERE status='Resolved'");
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Admin Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

/* ---------- BODY ---------- */
body{
    display:flex;
    min-height:100vh;
    background:linear-gradient(120deg,#e3f2fd,#f5f7fb); 
}

/* ---------- SIDEBAR ---------- */
.sidebar{
    width:270px;
    background:#0f172a;
    padding:30px 22px;
    color:#fff;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
    box-shadow:4px 0 20px rgba(0,0,0,0.15);
}

.sidebar h2{
    text-align:center;
    margin-bottom:40px;
    font-weight:600;
    letter-spacing:1px;
}

.sidebar a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 18px;
    margin-bottom:16px;
    text-decoration:none;
    color:#fff;
    border-radius:12px;
    background:#1e293b;
    transition:all .3s ease;
    font-weight:500;
}

.sidebar a:hover{
    background:#2563eb;
    transform:translateX(6px);
}

.sidebar a i{
    width:20px;
    text-align:center;
}

.logout{
    background:#dc2626!important;
}

.logout:hover{
    background:#b91c1c!important;
}

/* ---------- MAIN ---------- */
.main{
    flex:1;
    padding:45px;
}

/* ---------- HEADER ---------- */
.dashboard-header{
    background:#fff;
    padding:25px 30px;
    border-radius:18px;
    box-shadow:0 10px 30px rgba(0,0,0,.08);
    margin-bottom:40px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.dashboard-header h1{
    font-size:22px;
    font-weight:600;
    color:#0f172a;
}

.dashboard-header i{
    font-size:26px;
    color:#2563eb;
}

/* ---------- CARDS ---------- */
.stats{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(260px,1fr));
    gap:28px;
}

.card{
    background:#fff;
    border-radius:20px;
    padding:30px 25px;
    display:flex;
    align-items:center;
    gap:22px;
    box-shadow:0 12px 30px rgba(0,0,0,.08);
    transition:all .3s ease;
    position:relative;
    overflow:hidden;
}

.card:hover{
    transform:translateY(-8px);
    box-shadow:0 18px 40px rgba(0,0,0,.12);
}

.card i{
    font-size:42px;
}

.card h3{
    font-size:34px;
    margin-bottom:5px;
    color:#0f172a;
}

.card p{
    font-size:14px;
    color:#64748b;
    font-weight:500;
}

/* Top Accent Line */
.card::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:5px;
}

/* Color Variants */
.officers::before{ background:#2563eb; }
.complaints::before{ background:#f59e0b; }
.pending::before{ background:#ef4444; }
.processed::before{ background:#0ea5e9; }
.resolved::before{ background:#22c55e; }
.feedback::before{ background:#8b5cf6; }

.officers i{ color:#2563eb; }
.complaints i{ color:#f59e0b; }
.pending i{ color:#ef4444; }
.processed i{ color:#0ea5e9; }
.resolved i{ color:#22c55e; }
.feedback i{ color:#8b5cf6; }

/* ---------- RESPONSIVE ---------- */
@media(max-width:768px){
    .sidebar{
        display:none;
    }
    .main{
        padding:25px;
    }
}
</style>
</head>

<body>

<!-- ---------- SIDEBAR ---------- -->
<div class="sidebar">
    <div>
        <h2><i class="fa-solid fa-user-shield"></i> Admin Dashboard </h2>

        <a href="admin_panel.php">
            <i class="fa-solid fa-chart-line"></i> Dashboard
        </a>

        <a href="add_officer.php">
            <i class="fa-solid fa-user-plus"></i> Add Officer
        </a>

        <a href="complient_management.php">
            <i class="fa-solid fa-list"></i> Complaints
        </a>

        <a href="view_feedback.php">
            <i class="fa-solid fa-comments"></i> Feedback
        </a>
    </div>

    <a href="admin_logout.php" class="logout">
        <i class="fa-solid fa-right-from-bracket"></i> Logout
    </a>
</div>

<!-- ---------- MAIN ---------- -->
<div class="main">

<div class="dashboard-header">
    <h1>System Overview Dashboard</h1>
    <i class="fa-solid fa-gauge-high"></i>
</div>

<div class="stats">

    <div class="card officers">
        <i class="fa-solid fa-users"></i>
        <div>
            <h3><?= $totalOfficers ?></h3>
            <p>Total Officers</p>
        </div>
    </div>

    <div class="card complaints">
        <i class="fa-solid fa-file-circle-exclamation"></i>
        <div>
            <h3><?= $totalComplaints ?></h3>
            <p>Total Complaints</p>
        </div>
    </div>

    <div class="card pending">
        <i class="fa-solid fa-hourglass-half"></i>
        <div>
            <h3><?= $pending ?></h3>
            <p>Pending Complaints</p>
        </div>
    </div>

    <div class="card processed">
        <i class="fa-solid fa-spinner"></i>
        <div>
            <h3><?= $processed ?></h3>
            <p>Processed Complaints</p>
        </div>
    </div>

    <div class="card resolved">
        <i class="fa-solid fa-circle-check"></i>
        <div>
            <h3><?= $resolved ?></h3>
            <p>Resolved Complaints</p>
        </div>
    </div>

    <div class="card feedback">
        <i class="fa-solid fa-comments"></i>
        <div>
            <h3><?= $totalFeedback ?></h3>
            <p>Total Feedback</p>
        </div>
    </div>

</div>
</div>

</body>
</html>