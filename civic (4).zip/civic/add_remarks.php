<?php
session_start();
include 'db.php';

date_default_timezone_set('Asia/Kolkata');

/* ---------- AUTH CHECK ---------- */
if (!isset($_SESSION['officer_id'])) {
    header("Location: officer_login.php");
    exit;
}

$success = $error = "";
$complaint = null;

/* ---------- GET COMPLAINT ID ---------- */
$cid = (int)($_GET['id'] ?? $_POST['complaint_id'] ?? 0);
if ($cid <= 0) {
    die("Invalid complaint ID");
}

/* ---------- FETCH COMPLAINT ---------- */
$stmt = $conn->prepare("
    SELECT complaint_code, category, status, remarks
    FROM complaints
    WHERE id = ?
");
$stmt->bind_param("i", $cid);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    die("Complaint not found");
}
$complaint = $res->fetch_assoc();

/* ---------- SAVE REMARK ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $remarks = trim($_POST['remarks'] ?? '');

    if ($remarks === '') {
        $error = "Remarks cannot be empty";
    } else {

        $up = $conn->prepare("
            UPDATE complaints
            SET remarks = ?, updated_at = NOW()
            WHERE id = ?
        ");
        $up->bind_param("si", $remarks, $cid);

        if ($up->execute()) {
            $success = "Remarks updated successfully";
            $complaint['remarks'] = $remarks;
        } else {
            $error = "Failed to update remarks";
        }
    }
}

function h($v){
    return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Add Remarks</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body{
    margin:0;
    font-family:Inter,Arial;
    background:linear-gradient(135deg,#eef2ff,#f8fafc)
}
.container{
    max-width:700px;
    margin:60px auto;
    padding:20px
}
.card{
    background:#fff;
    border-radius:22px;
    box-shadow:0 25px 55px rgba(0,0,0,.15);
    padding:30px
}
h2{
    margin-top:0;
    text-align:center
}
.sub{
    text-align:center;
    color:#64748b;
    margin-bottom:25px
}

.row{
    margin-bottom:14px;
    font-size:15px
}
.row strong{
    width:150px;
    display:inline-block;
    color:#334155
}

textarea{
    width:100%;
    min-height:120px;
    padding:14px;
    border-radius:14px;
    border:1px solid #cbd5e1;
    font-size:15px;
    resize:vertical
}

.btn{
    background:#2563eb;
    color:#fff;
    padding:12px 26px;
    border-radius:14px;
    font-weight:600;
    border:none;
    cursor:pointer;
    text-decoration:none;
    display:inline-block
}
.btn.gray{background:#64748b}

.alert{
    margin-top:16px;
    padding:14px;
    border-radius:12px;
    font-size:15px
}
.success{
    background:#dcfce7;
    color:#166534
}
.error{
    background:#fee2e2;
    color:#991b1b
}

.footer{
    text-align:center;
    margin-top:25px
}
</style>
</head>

<body>
<div class="container">

<div class="card">
<h2>📝 Add Officer Remarks</h2>
<div class="sub">Update complaint remarks</div>

<div class="row"><strong>Complaint ID:</strong> <?php echo h($complaint['complaint_code']); ?></div>
<div class="row"><strong>Category:</strong> <?php echo ucfirst(h($complaint['category'])); ?></div>
<div class="row"><strong>Status:</strong> <?php echo h($complaint['status']); ?></div>

<form method="post">
<input type="hidden" name="complaint_id" value="<?php echo $cid; ?>">

<label><strong>Remarks</strong></label>
<textarea name="remarks" placeholder="Enter officer remarks here..."><?php echo h($complaint['remarks'] ?? ''); ?></textarea>

<button class="btn" type="submit">💾 Save Remarks</button>
<a href="officer_complients.php" class="btn gray">⬅ Back</a>
</form>

<?php if ($success): ?>
<div class="alert success"><?php echo h($success); ?></div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert error"><?php echo h($error); ?></div>
<?php endif; ?>

</div>

<div class="footer">
© <?php echo date("Y"); ?>Civic Issues Reporting System
</div>

</div>
</body>
</html>
