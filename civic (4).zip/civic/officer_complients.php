<?php
session_start();
include 'db.php';

date_default_timezone_set('Asia/Kolkata');

/* ---------- AUTH CHECK ---------- */
if (!isset($_SESSION['officer_id'], $_SESSION['officer_dept'])) {
    header('Location: officer_login.php');
    exit;
}


$officer_id   = $_SESSION['officer_id'];
$dept         = strtolower($_SESSION['officer_dept']);
$officer_name = $_SESSION['officer_name'] ?? 'Officer';

function h($v){
    return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8');
}

/* ---------- FILTER VALUES ---------- */
$from   = $_GET['from'] ?? '';
$to     = $_GET['to'] ?? '';
$status = $_GET['status'] ?? '';

/* ---------- BUILD WHERE ---------- */
$where  = "WHERE LOWER(c.category) = ?";
$params = [$dept];
$types  = "s";

if ($from && $to) {
    $where .= " AND DATE(c.date_time) BETWEEN ? AND ?";
    $params[] = $from;
    $params[] = $to;
    $types   .= "ss";
}

if (!empty($status)) {
    $where .= " AND c.status = ?";
    $params[] = $status;
    $types   .= "s";
}
/* ---------- CSV DOWNLOAD (FIXED) ---------- */
if (isset($_GET['download'])) {

    $sqlCsv = "
    SELECT complaint_code, category, priority, date_time, status, user_phone, user_email
    FROM complaints c
    $where
    ORDER BY c.date_time DESC
    ";

    $stmtCsv = $conn->prepare($sqlCsv);
    $stmtCsv->bind_param($types, ...$params);
    $stmtCsv->execute();
    $csvRes = $stmtCsv->get_result();

    header("Content-Type: text/csv");
    header("Content-Disposition: attachment; filename={$dept}_complaints.csv");

    echo "Complaint Code,Category,Priority,Date,Status,Phone,Email\n";
    while ($r = $csvRes->fetch_assoc()) {
        echo "{$r['complaint_code']},{$r['category']},{$r['priority']},{$r['date_time']},{$r['status']},{$r['user_phone']},{$r['user_email']}\n";
    }
    exit;
}

/* ---------- FETCH COMPLAINTS ---------- */
$sql = "
SELECT 
    c.id,
    c.complaint_code,
    c.category,
    c.date_time,
    c.status,
    c.priority,
    c.user_phone,
    c.user_email,
    c.description,
    c.photo_path,
    c.latitude,
    c.longitude,
    c.remarks
FROM complaints c
$where
ORDER BY c.date_time DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
<title>Officer Complaints</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
:root{
    --primary:#2563eb;
    --dark:#0f172a;
    --muted:#64748b;
}

body{
    margin:0;
    font-family:'Inter',Arial,sans-serif;
    background:linear-gradient(135deg,#eef2ff,#f8fafc);
}

.container{
    max-width:1400px;
    margin:auto;
    padding:28px;
}

/* HEADER */
.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
}
.header h2{margin:0}

/* BUTTONS */
.btn{
    height:46px;
    padding:0 22px;
    border-radius:14px;
    font-weight:700;
    border:none;
    cursor:pointer;
    text-decoration:none;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    transition:.25s;
}
.btn:hover{transform:translateY(-2px)}
.btn{background:var(--primary);color:#fff}
.btn.gray{background:#64748b}
.btn.green{background:#16a34a}
.btn.orange{background:#ea580c}

/* FILTER BAR */
.filter{
    background:#ffffff;
    padding:20px;
    border-radius:22px;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(190px,1fr));
    gap:18px;
    align-items:end;
    box-shadow:0 15px 35px rgba(0,0,0,.1);
    margin-bottom:35px;
}

.filter label{
    font-size:13px;
    font-weight:700;
    color:#475569;
    margin-bottom:6px;
    display:block;
}

.filter input,
.filter select{
    height:46px;
    width:80%;
    padding:0 14px;
    border-radius:14px;
    border:1px solid #cbd5e1;
    font-weight:600;
    background:#f8fafc;
}

/* CARD */
.card{
    background:#fff;
    border-radius:28px;
    box-shadow:0 30px 60px rgba(0,0,0,.12);
    margin-bottom:36px;
    overflow:hidden;
}

.card-body{
    display:grid;
    grid-template-columns:1.6fr 0.7fr;
    gap:30px;
    padding:30px;
}

/* STATUS */
.badge{
    padding:7px 20px;
    border-radius:999px;
    font-weight:800;
    font-size:13px;
    float:right;
}
.pending{background:#fde68a}
.inprogress{background:#c7d2fe}
.resolved{background:#bbf7d0}
.rejected{background:#fecaca}

/* META */
.meta{
    font-size:14px;
    color:#475569;
    margin:14px 0;
}
.meta span{display:block;margin-bottom:6px}

.desc{font-size:15px;margin:14px 0}

/* IMAGE */
.photo-box{
    width:100%;
    max-width:400px;
    height:240px;
    border-radius:20px;
    overflow:hidden;
    background:#e5e7eb;
}
.photo-box img{
    width:100%;
    height:100%;
    object-fit:cover;
}

/* RIGHT PANEL */
.right{
    background:#f8fafc;
    padding:22px;
    border-radius:22px;
}

.right select,
.right textarea{
    width:100%;
    height:46px;
    padding:10px 14px;
    border-radius:14px;
    border:1px solid #cbd5e1;
    margin-bottom:12px;
}
.right textarea{height:auto}

/* MOBILE */
@media(max-width:900px){
    .card-body{grid-template-columns:1fr}
}
</style>
</head>

<body>
<div class="container">

<div class="header">
    <div>
        <h2>👮 <?php echo h($officer_name); ?></h2>
        <div><?php echo ucfirst(h($dept)); ?> Department</div>
    </div>
    <a href="officer_dashboard.php" class="btn gray">⬅ Back</a>
</div>

<form class="filter" method="get">
    <div>
        <label>From Date</label>
        <input type="date" name="from" value="<?php echo h($from); ?>">
    </div>
    <div>
        <label>To Date</label>
        <input type="date" name="to" value="<?php echo h($to); ?>">
    </div>
    <div>
        <label>Status</label>
        <select name="status">
            <option value="">All</option>
            <option <?php if($status=="Pending") echo "selected"; ?>>Pending</option>
            <option <?php if($status=="In Progress") echo "selected"; ?>>In Progress</option>
            <option <?php if($status=="Resolved") echo "selected"; ?>>Resolved</option>
            <option <?php if($status=="Rejected") echo "selected"; ?>>Rejected</option>
        </select>
    </div>
    <button class="btn">Apply</button>
    <a href="?download=1" class="btn orange">⬇ Download</a>
</form>

<?php while($row = $res->fetch_assoc()):
$statusClass = strtolower(str_replace(' ','',$row['status']));
?>

<div class="card">
<div class="card-body">

<div>
<strong>🆔 <?php echo h($row['complaint_code']); ?></strong>
<span class="badge <?php echo $statusClass; ?>"><?php echo h($row['status']); ?></span>

<div class="meta">
    <span>📅 <?php echo date("d-m-Y h:i A", strtotime($row['date_time'])); ?></span>
    <span>📞 <?php echo h($row['user_phone']); ?></span>
    <span>📧 <?php echo h($row['user_email']); ?></span>
    <span>⚡ Priority: <?php echo h($row['priority']); ?></span>
</div>

<div class="desc"><?php echo nl2br(h($row['description'])); ?></div>

<?php if($row['photo_path']): ?>
<div class="photo-box">
<img src="<?php echo h($row['photo_path']); ?>">
</div>
<?php endif; ?>

<?php if($row['latitude'] && $row['longitude']): ?>
<br><br>
<a class="btn orange" target="_blank"
href="https://www.google.com/maps?q=<?php echo $row['latitude']; ?>,<?php echo $row['longitude']; ?>">
📍 View Location
</a>
<?php endif; ?>
</div>

<div class="right">
<?php if(!in_array($row['status'],['Resolved','Rejected'])): ?>

<form method="post" action="update_status.php">
<input type="hidden" name="complaint_id" value="<?php echo (int)$row['id']; ?>">
<select name="status">
<option>Pending</option>
<option>In Progress</option>
<option>Resolved</option>
<option>Rejected</option>
</select>
<button class="btn green">Update Status</button>
<p></p>
</form>


<form method="post" action="add_remarks.php">

<input type="hidden" name="complaint_id" value="<?php echo (int)$row['id']; ?>">
<textarea name="remarks" rows="3"><?php echo h($row['remarks']); ?></textarea>

<button class="btn">Save Remarks</button>
</form>

<?php else: ?>
<p><strong>✅ Complaint Closed</strong></p>
<?php endif; ?>
</div>

</div>
</div>

<?php endwhile; ?>

</div>
</body>
</html>
