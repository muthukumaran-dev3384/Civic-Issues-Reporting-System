<?php
session_start();
include 'db.php';

/* ---------- LOGIN CHECK ---------- */
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit;
}

$userEmail = $_SESSION['email'];

/* ---------- FETCH USER COMPLAINT HISTORY ---------- */
$sql = "
SELECT 
    id,
    complaint_code,
    category,
    priority,
    status,
    description,
    photo_path,
    date_time,
    remarks,
    city,
    area,
    road
FROM complaints
WHERE user_email = ?
ORDER BY date_time DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $userEmail);
$stmt->execute();
$res = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Complaint History | Smart Civic</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet"
 href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root{
  --primary:#0d47a1;
  --bg:#f1f5f9;
  --card:#ffffff;
  --muted:#64748b;
  --shadow:0 16px 40px rgba(0,0,0,.15);
}
*{box-sizing:border-box}
body{
    margin:0;
    font-family:"Segoe UI",Arial,sans-serif;
    background:linear-gradient(135deg,#eef2ff,#f8fafc);
}

/* HEADER */
.header{
    background:linear-gradient(90deg,#0d47a1,#1976d2);
    color:#fff;
    padding:18px 26px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}
.header a{
    color:#fff;
    text-decoration:none;
    font-weight:600;
    background:rgba(255,255,255,.2);
    padding:8px 14px;
    border-radius:10px;
}

/* CONTAINER */
.container{
    max-width:1200px;
    margin:30px auto;
    padding:0 20px;
}

/* EMPTY */
.empty{
    background:#fff;
    padding:40px;
    border-radius:20px;
    box-shadow:var(--shadow);
    text-align:center;
}

/* GRID */
.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(340px,1fr));
    gap:26px;
}

/* CARD */
.card{
    background:#fff;
    padding:22px;
    border-radius:22px;
    box-shadow:var(--shadow);
    border-top:6px solid var(--primary);
    transition:.25s;
}
.card:hover{transform:translateY(-6px)}

/* BADGE */
.badge{
    padding:6px 14px;
    border-radius:999px;
    font-size:13px;
    font-weight:700;
    color:#fff;
    display:inline-block;
    margin-top:6px;
}
.pending{background:#f59e0b}
.inprogress{background:#2563eb}
.resolved{background:#16a34a}
.rejected{background:#dc2626}

/* META */
.meta{
    font-size:13px;
    color:var(--muted);
    margin-bottom:10px;
}
.meta span{display:block;margin-bottom:4px}

/* IMAGE */
.photo{
    width:100%;
    border-radius:14px;
    margin-top:12px;
}

/* REMARKS */
.remarks{
    background:#eef4ff;
    padding:14px;
    border-left:4px solid var(--primary);
    border-radius:12px;
    margin-top:14px;
    font-size:14px;
}

/* FOOTER */
.footer{
    text-align:center;
    padding:16px;
    margin-top:40px;
    background:#e2e8f0;
    font-size:13px;
}
</style>
</head>

<body>

<div class="header">
  <h2><i class="fa-solid fa-clock-rotate-left"></i> My Complaint History</h2>
  <a href="index.php"><i class="fa-solid fa-arrow-left"></i> Back</a>
</div>

<div class="container">

<?php if ($res->num_rows === 0): ?>
  <div class="empty">
      <i class="fa-solid fa-folder-open fa-3x"></i>
      <h3>No Complaints Found</h3>
      <p>You have not submitted any complaints yet.</p>
  </div>
<?php else: ?>

<div class="cards">

<?php while ($row = $res->fetch_assoc()):
$status = strtolower(str_replace(' ','',$row['status']));
$date = date("d M Y, h:i A", strtotime($row['date_time']));
?>

<div class="card">

<h3>🆔 <?= htmlspecialchars($row['complaint_code']) ?></h3>

<div class="meta">
<span>📂 Category: <?= ucfirst(htmlspecialchars($row['category'])) ?></span>
<span>⚡ Priority: <?= htmlspecialchars($row['priority']) ?></span>
<span>📍 Location: <?= htmlspecialchars($row['area'] . ", " . $row['city']) ?></span>
<span>📅 Submitted: <?= $date ?></span>
</div>

<span class="badge <?= $status ?>">
<?= htmlspecialchars($row['status']) ?>
</span>

<p style="margin-top:14px">
<?= nl2br(htmlspecialchars($row['description'])) ?>
</p>

<?php if (!empty($row['photo_path'])): ?>
<img class="photo" src="<?= htmlspecialchars($row['photo_path']) ?>">
<?php endif; ?>

<?php if (!empty(trim($row['remarks']))): ?>
<div class="remarks">
<strong>🗒 Officer Update:</strong><br>
<?= nl2br(htmlspecialchars($row['remarks'])) ?>
</div>
<?php endif; ?>

</div>

<?php endwhile; ?>

</div>
<?php endif; ?>

</div>

<div class="footer">
© <?= date("Y") ?> Civic Issues Reporting System
</div>

</body>
</html>