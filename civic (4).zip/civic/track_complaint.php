<?php
include 'db.php';

$complaint = null;
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $code = trim($_POST['complaint_code'] ?? '');

    if ($code === "") {
        $error = "Please enter Complaint ID";
    } else {

        $stmt = $conn->prepare("
            SELECT 
                complaint_code,
                category,
                status,
                priority,
                date_time,
                updated_at,
                remarks
            FROM complaints
            WHERE complaint_code = ?
        ");

        if ($stmt) {
            $stmt->bind_param("s", $code);
            $stmt->execute();
            $res = $stmt->get_result();

            if ($res->num_rows === 0) {
                $error = "Complaint not found";
            } else {
                $complaint = $res->fetch_assoc();
            }
        } else {
            $error = "Database error";
        }
    }
}

function h($v){
    return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Track Complaint Status</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
/* --- SAME CSS AS BEFORE (UNCHANGED) --- */
body{
    margin:0;
    font-family:Inter,Arial,sans-serif;
    background:linear-gradient(135deg,#e0f2fe,#f8fafc);
}
.container{
    max-width:900px;
    margin:100px auto;
    padding:20px;
}
.card{
    background:#fff;
    border-radius:26px;
    box-shadow:0 30px 60px rgba(0,0,0,.15);
    padding:36px;
}
.header{text-align:center;margin-bottom:30px}
.header h2{margin:0;font-size:30px}
.header p{color:#64748b;margin-top:6px}

label{font-weight:600;margin-top:18px;display:block}
input{
    width:100%;
    padding:14px;
    border-radius:14px;
    border:1px solid #cbd5e1;
    margin-top:8px;
    font-size:15px;
}
button{
    margin-top:24px;
    width:100%;
    background:#2563eb;
    color:#fff;
    border:none;
    padding:15px;
    border-radius:18px;
    font-size:17px;
    font-weight:700;
    cursor:pointer;
}
button:hover{background:#1d4ed8}

.error{
    margin-top:22px;
    background:#fee2e2;
    color:#991b1b;
    padding:16px;
    border-radius:16px;
    font-weight:600;
}
.row{margin-bottom:14px;font-size:15px}
.row strong{display:inline-block;width:170px;color:#334155}

.badge{
    padding:8px 22px;
    border-radius:999px;
    font-weight:800;
    font-size:14px;
}
.pending{background:#fde68a}
.inprogress{background:#c7d2fe}
.resolved{background:#bbf7d0}
.rejected{background:#fecaca}

.timeline{
    margin-top:30px;
    border-left:4px solid #2563eb;
    padding-left:22px;
}
.time-item{margin-bottom:22px;position:relative}
.time-item::before{
    content:'';
    width:14px;height:14px;
    background:#2563eb;
    border-radius:50%;
    position:absolute;
    left:-31px;top:5px;
}
.time-item span{font-size:13px;color:#64748b}

.remarks{
    margin-top:28px;
    padding:22px;
    background:#eef4ff;
    border-left:6px solid #2563eb;
    border-radius:18px;
    font-size:15px;
}
.btn{background:#64748b;color:#fff;margin-top:2px;padding:10px 18px;border-radius:14px;text-decoration:none;font-weight:600}
</style>
</head>

<body>

<div class="container">

<a href="user_dashboard.php" class="btn">⬅ Back</a>

<div class="card">

<div class="header">
<h2>🔍 Track Complaint</h2>
<p>Check live complaint status & officer remarks</p>
</div>

<form method="post">
<label>Complaint ID</label>
<input type="text" name="complaint_code" placeholder="Enter Complaint ID" required>

<button type="submit">🔎 Check Status</button>
</form>

<?php if ($error): ?>
<div class="error"><?php echo h($error); ?></div>
<?php endif; ?>

<?php if ($complaint):
$statusClass = strtolower(str_replace(' ', '', $complaint['status']));
?>

<hr style="margin:40px 0">

<div class="row"><strong>Complaint ID:</strong> <?php echo h($complaint['complaint_code']); ?></div>
<div class="row"><strong>Category:</strong> <?php echo ucfirst(h($complaint['category'])); ?></div>
<div class="row"><strong>Priority:</strong> <?php echo h($complaint['priority']); ?></div>

<div class="row">
<strong>Status:</strong>
<span class="badge <?php echo $statusClass; ?>">
<?php echo h($complaint['status']); ?>
</span>
</div>

<div class="timeline">
<div class="time-item">
<strong>🕒 Submitted</strong><br>
<span><?php echo date("d M Y, h:i A", strtotime($complaint['date_time'])); ?></span>
</div>

<div class="time-item">
<strong>🔄 Last Updated</strong><br>
<span>
<?php
echo $complaint['updated_at']
? date("d M Y, h:i A", strtotime($complaint['updated_at']))
: "Not updated yet";
?>
</span>
</div>
</div>

<?php if (!empty($complaint['remarks'])): ?>
<div class="remarks">
<strong>📝 Officer Remarks</strong><br><br>
<?php echo nl2br(h($complaint['remarks'])); ?>
</div>
<?php endif; ?>

<?php endif; ?>

</div>
</div>

</body>
</html>