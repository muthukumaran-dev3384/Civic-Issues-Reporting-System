<?php
include 'db.php';

$success = "";
$error   = "";

/* ---------- FORM SUBMIT ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email   = trim($_POST['email'] ?? '');
    $rating  = intval($_POST['rating'] ?? 0);
    $message = trim($_POST['message'] ?? '');

    if ($email === "" || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif ($rating < 1 || $rating > 5) {
        $error = "Please select a star rating.";
    } elseif ($message === "") {
        $error = "Feedback message cannot be empty.";
    } else {

        $stmt = $conn->prepare(
            "INSERT INTO feedback (user_email, rating, message)
             VALUES (?, ?, ?)"
        );
        $stmt->bind_param("sis", $email, $rating, $message);

        if ($stmt->execute()) {
            $success = "✅ Thank you! Your feedback has been submitted successfully.";
        } else {
            $error = "❌ Database error. Please try again.";
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>User Feedback</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

<style>
*{box-sizing:border-box}
body{
    margin:0;
    font-family:Poppins,Arial,sans-serif;
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(120deg,#e3f2fd,#f5f7fb);
}

.container{
    width:100%;
    max-width:500px;
    padding:20px;
}

.card{
    background:#fff;
    border-radius:20px;
    padding:28px;
    box-shadow:0 20px 40px rgba(0,0,0,.25);
    position:relative;
}

/* ---------- BACK BUTTON ---------- */
.back-btn{
    position:absolute;
    top:20px;
    left:20px;
    text-decoration:none;
    color:#667eea;
    font-size:14px;
    font-weight:600;
}
.back-btn i{margin-right:6px}

h2{
    text-align:center;
    margin:10px 0 20px;
    font-weight:600;
}

/* ---------- FORM ---------- */
input, textarea{
    width:100%;
    padding:13px;
    border-radius:12px;
    border:1.8px solid #cfd8dc;
    font-size:15px;
    margin-bottom:15px;
}
input:focus, textarea:focus{
    outline:none;
    border-color:#667eea;
}
textarea{
    min-height:110px;
    resize:none;
}

/* ---------- STAR RATING (LEFT → RIGHT) ---------- */
.stars{
    display:flex;
    flex-direction:row-reverse; /* 🔑 MAGIC LINE */
    justify-content:center;
    gap:8px;
    margin-bottom:18px;
}

.stars input{
    display:none;
}

.stars label{
    font-size:32px;
    color:#ccc;
    cursor:pointer;
    transition:.2s;
}

/* Hover effect */
.stars label:hover,
.stars label:hover ~ label{
    color:#fbbf24;
}

/* Checked stars */
.stars input:checked ~ label{
    color:#fbbf24;
}
/* ---------- BUTTON ---------- */
.btn{
    width:100%;
    padding:14px;
    border:none;
    border-radius:14px;
    background:#667eea;
    color:#fff;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
}
.btn:hover{background:#5563d6}

/* ---------- MESSAGES ---------- */
.msg{
    text-align:center;
    padding:12px;
    margin-bottom:15px;
    border-radius:10px;
    font-weight:600;
}
.success{background:#dcfce7;color:#166534}
.error{background:#fee2e2;color:#991b1b}
</style>
</head>

<body>

<div class="container">
    <div class="card">

        <a href="user_dashboard.php" class="back-btn">
            <i class="fa fa-arrow-left"></i> Back
        </a>

        <h2>⭐ User Feedback</h2>

        <?php if($success): ?><div class="msg success"><?= $success ?></div><?php endif; ?>
        <?php if($error): ?><div class="msg error"><?= $error ?></div><?php endif; ?>

        <form method="POST">

            <input type="email" name="email" placeholder="Your Email" required>

           <div class="stars">
    <input type="radio" name="rating" id="star5" value="5">
    <label for="star5">★</label>

    <input type="radio" name="rating" id="star4" value="4">
    <label for="star4">★</label>

    <input type="radio" name="rating" id="star3" value="3">
    <label for="star3">★</label>

    <input type="radio" name="rating" id="star2" value="2">
    <label for="star2">★</label>

    <input type="radio" name="rating" id="star1" value="1">
    <label for="star1">★</label>
</div>

            <textarea name="message" placeholder="Write your feedback..." required></textarea>

            <button class="btn">
                <i class="fa fa-paper-plane"></i> Submit Feedback
            </button>
        </form>

    </div>
</div>

</body>
</html>