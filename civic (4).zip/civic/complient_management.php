<?php
include 'db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

/* ---------------- FILTER LOGIC ---------------- */
$where = [];
$params = [];
$types  = "";

if (!empty($_GET['category'])) {
    $where[] = "c.category = ?";
    $params[] = $_GET['category'];
    $types .= "s";
}

if (!empty($_GET['status'])) {
    $where[] = "c.status = ?";
    $params[] = $_GET['status'];
    $types .= "s";
}

if (!empty($_GET['from_date']) && !empty($_GET['to_date'])) {
    $where[] = "DATE(c.date_time) BETWEEN ? AND ?";
    $params[] = $_GET['from_date'];
    $params[] = $_GET['to_date'];
    $types .= "ss";
}

/* ---------------- MAIN QUERY ---------------- */
$sql = "
SELECT 
    c.complaint_code,
    c.user_email AS user_id,
    c.category,
    c.description,
    c.status,
    c.priority,
    c.remarks,
    c.date_time
FROM complaints c
";

if ($where) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY c.date_time DESC";

/* ---------------- EXECUTE QUERY ---------------- */
$stmt = $conn->prepare($sql);
if (!$stmt) { die("SQL Prepare Failed: " . $conn->error); }
if (!empty($params)) { $stmt->bind_param($types, ...$params); }
if (!$stmt->execute()) { die("SQL Execute Failed: " . $stmt->error); }
$result = $stmt->get_result();
if (!$result) { die("Result Error: " . $stmt->error); }

/* ---------------- CSV DOWNLOAD ---------------- */
if (isset($_GET['download']) && $_GET['download'] == 1) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=complaints_report.csv');
    $out = fopen("php://output", "w");

    // CSV HEADER
    fputcsv($out, [
        'Complaint ID','User Email','Category',
        'Description','Status','Priority','Remarks','Date & Time'
    ]);

    // DATA ROWS
    while ($row = $result->fetch_assoc()) {
        fputcsv($out, [
            $row['complaint_code'],
            $row['user_id'],
            $row['category'],
            $row['description'],
            $row['status'],
            $row['priority'],
            $row['remarks'],
            $row['date_time']
        ]);
    }

    fclose($out);
    exit; // important to stop HTML output
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Complaint Management</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
*{
    box-sizing:border-box;
    margin:0;
    padding:0;
    font-family:'Segoe UI',Arial,sans-serif;
}

body{
    background:linear-gradient(120deg,#e3f2fd,#f5f7fb); /* NOT CHANGED */
    min-height:100vh;
    padding:40px 20px;
}

/* CONTAINER */
.container{
    max-width:1400px;
    margin:auto;
}

/* CARD */
.card{
    background:rgba(255,255,255,0.10);
    backdrop-filter:blur(14px);
    border-radius:18px;
    padding:35px;
    box-shadow:0 15px 35px rgba(0,0,0,0.25);
}

/* HEADER */
.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
}

.header h1{
    font-size:26px;
    font-weight:700;
    color:#0f172a;
}

.btn-back{
    background:#ef4444;
    color:#fff;
    padding:10px 16px;
    border-radius:8px;
    text-decoration:none;
    font-weight:600;
    display:flex;
    align-items:center;
    gap:6px;
    transition:.3s;
}
.btn-back:hover{
    background:#dc2626;
}

/* FILTER */
.filter-box{
    display:flex;
    flex-wrap:wrap;
    gap:15px;
    align-items:center;
    margin-bottom:25px;
}

.filter-box select,
.filter-box input{
    padding:11px 14px;
    border-radius:8px;
    border:1px solid #cbd5e1;
    font-size:14px;
    min-width:170px;
    background:#fff;
    outline:none;
}

.filter-box select:focus,
.filter-box input:focus{
    border-color:#2563eb;
    box-shadow:0 0 0 2px rgba(37,99,235,0.2);
}

.filter-box button{
    padding:11px 20px;
    border-radius:8px;
    border:none;
    background:#2563eb;
    color:#fff;
    font-weight:600;
    cursor:pointer;
    display:flex;
    align-items:center;
    gap:8px;
    transition:.3s;
}
.filter-box button:hover{
    background:#1d4ed8;
}

/* TABLE */
.table-wrapper{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
    margin-top:10px;
    border-radius:12px;
    overflow:hidden;
}

th{
    background:#0f172a;
    color:#fff;
    padding:14px;
    font-size:14px;
    text-align:left;
}

td{
    padding:13px;
    font-size:14px;
    color:#0f172a;
    background:#ffffff;
    border-bottom:1px solid #e2e8f0;
}

tr:nth-child(even) td{
    background:#f8fafc;
}

tr:hover td{
    background:#e0f2fe;
    transition:.2s;
}

/* STATUS BADGES */
.status-badge{
    padding:5px 10px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
    display:inline-block;
}

.pending{background:#fff3cd;color:#856404;}
.inprogress{background:#cff4fc;color:#055160;}
.resolved{background:#d1e7dd;color:#0f5132;}
.rejected{background:#f8d7da;color:#842029;}

/* DOWNLOAD BUTTON */
.actions{
    display:flex;
    justify-content:flex-end;
    margin-top:25px;
}

.download{
    background:#22c55e;
    color:#fff;
    padding:11px 20px;
    border-radius:8px;
    text-decoration:none;
    font-weight:600;
    display:flex;
    align-items:center;
    gap:8px;
    transition:.3s;
}
.download:hover{
    background:#16a34a;
}

/* RESPONSIVE */
@media(max-width:768px){
    .header{
        flex-direction:column;
        align-items:flex-start;
        gap:15px;
    }
    .filter-box{
        flex-direction:column;
        align-items:stretch;
    }
    .actions{
        justify-content:center;
    }
}
</style>
</head>

<body>
<div class="container">
<div class="card">

<div class="header">
    <h1><i class="fa fa-folder-open"></i> Complaint Management</h1>
    <a href="admin_panel.php" class="btn-back">
        <i class="fa fa-arrow-left"></i> Back
    </a>
</div>

<form method="GET" class="filter-box">
    <select name="category">
        <option value="">All Categories</option>
        <option value="road" <?= (isset($_GET['category']) && $_GET['category']=='road')?'selected':'' ?>>Road</option>
        <option value="water" <?= (isset($_GET['category']) && $_GET['category']=='water')?'selected':'' ?>>Water</option>
        <option value="electricity" <?= (isset($_GET['category']) && $_GET['category']=='electricity')?'selected':'' ?>>Electricity</option>
        <option value="garbage" <?= (isset($_GET['category']) && $_GET['category']=='garbage')?'selected':'' ?>>Garbage</option>
    </select>

    <select name="status">
        <option value="">All Status</option>
        <option value="Pending" <?= (isset($_GET['status']) && $_GET['status']=='Pending')?'selected':'' ?>>Pending</option>
        <option value="In Progress" <?= (isset($_GET['status']) && $_GET['status']=='In Progress')?'selected':'' ?>>In Progress</option>
        <option value="Resolved" <?= (isset($_GET['status']) && $_GET['status']=='Resolved')?'selected':'' ?>>Resolved</option>
        <option value="Rejected" <?= (isset($_GET['status']) && $_GET['status']=='Rejected')?'selected':'' ?>>Rejected</option>
    </select>

    <input type="date" name="from_date" value="<?= $_GET['from_date'] ?? '' ?>">
    <input type="date" name="to_date" value="<?= $_GET['to_date'] ?? '' ?>">

    <button type="submit">
        <i class="fa fa-filter"></i> Filter
    </button>
</form>

<div class="table-wrapper">
<table>
<tr>
    <th>Complaint ID</th>
    <th>User Email</th>
    <th>Category</th>
    <th>Description</th>
    <th>Status</th>
    <th>Priority</th>
    <th>Remarks</th>
    <th>Date & Time</th>
</tr>
<?php if(isset($result) && $result->num_rows > 0): ?>
    <?php while($c = $result->fetch_assoc()):
        $cls = strtolower(str_replace(' ','',$c['status']));
    ?>
    <tr>
        <td><?= htmlspecialchars($c['complaint_code']); ?></td>
        <td><?= htmlspecialchars($c['user_id']); ?></td>
        <td><?= ucfirst($c['category']); ?></td>
        <td><?= htmlspecialchars($c['description']); ?></td>
        <td><span class="status-badge <?= $cls; ?>"><?= $c['status']; ?></span></td>
        <td><?= htmlspecialchars($c['priority']); ?></td>
        <td><?= htmlspecialchars($c['remarks']); ?></td>
        <td><?= date("d-m-Y h:i A", strtotime($c['date_time'])); ?></td>
    </tr>
    <?php endwhile; ?>


<?php else: ?>
    <tr>
        <td colspan="8" style="text-align:center;padding:20px;">
            No complaints found.
        </td>
    </tr>
<?php endif; ?>
</table>
</div>

<div class="actions">
    <a href="?<?= http_build_query(array_merge($_GET,['download'=>1])); ?>" class="download">
        <i class="fa fa-download"></i> Download CSV
    </a>
</div>

</div>
</div>
</body>
</html>