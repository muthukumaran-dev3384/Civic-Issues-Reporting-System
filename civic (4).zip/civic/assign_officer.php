<?php
include 'db.php';
if (!isset($_SESSION['officer_id'])) { header('Location: officer_login.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') die('Invalid');
$complaint_id = (int)$_POST['complaint_id'];
$officer_id = (int)$_POST['officer_id'];
$u = $conn->prepare('UPDATE complaints SET assigned_officer = ? WHERE id = ?');
$u->bind_param('ii', $officer_id, $complaint_id);
$u->execute();
header('Location: officer_complients.php');
exit;
?>