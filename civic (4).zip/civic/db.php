<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$conn = new mysqli("localhost", "root", "", "civic_portal");
if ($conn->connect_error) {
    die("DB Connection Failed: " . $conn->connect_error);
}

/**
 * Generate complaint code like TNRD-001
 */
function generateComplaintCode(mysqli $conn, string $category): string
{
    $map = [
        'road'        => 'TNRD',
        'water'       => 'TNWT',
        'electricity' => 'TNEL',
        'garbage'     => 'TNGB',
        'streetlight' => 'TNSL',
        'drainage'    => 'TNDR'
    ];

    $prefix = $map[strtolower($category)] ?? 'TNCM';

    $stmt = $conn->prepare("
        SELECT complaint_code
        FROM complaints
        WHERE complaint_code LIKE CONCAT(?, '-%')
        ORDER BY id DESC
        LIMIT 1
    ");
    $stmt->bind_param("s", $prefix);
    $stmt->execute();
    $res = $stmt->get_result();

    $next = 1;
    if ($row = $res->fetch_assoc()) {
        $num = (int)substr($row['complaint_code'], strlen($prefix) + 1);
        $next = $num + 1;
    }

    return sprintf("%s-%03d", $prefix, $next);
}
